<?php
//ارتقا دهنده دیباگ کننده سورس @HOKOMAT_ARAB
//اولین چنل اوپن کننده @Virtualservices_3
//بی ناموسی منبع پاک کنی با افتخار به سعید افکونی
error_reporting(0);
ob_start();
$day = (2505600 - (time() - filectime('Mahdy'))) / 60 / 60 / 24;
$day = round($day, 0);
$LrixeNumber = "[*[TOKEN]*]";
define('API_KEY',$LrixeNumber);
echo file_get_contents("https://api.telegram.org/bot$LrixeNumber/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$Virtualservices_3 = http_build_query($datas);
$url = "https://api.telegram.org/bot".API_KEY."/".$method."?$Virtualservices_3";
$Virtualservices_3 = file_get_contents($url);
return json_decode($Virtualservices_3);}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$message = $update->message;
$username = $message->from->username;
$message_id2 = $update->callback_query->message->message_id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$Name = $update->callback_query->from->first_name;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$useree = $update->callback_query->message->chat->id;
$username = $message->from->username;
$fn = $message->from->first_name;
$user_id = $message->from->id;
$admin = "[*[ADMIN]*]";
$from_id = $message->from->id;
$user_id = $message->from->id;
mkdir("LrixeNumber941");
mkdir("DevOscar");
$useree = $update->callback_query->message->chat->id;
$Name = $update->callback_query->from->first_name;
$LrixeNumber = file_get_contents("LrixeNumber.txt");
$LrixeNumber0 = file_get_contents("LrixeNumber0.txt");
$LrixeNumber1= file_get_contents("LrixeNumber1.txt");
$LrixeNumber5 = file_get_contents("LrixeNumber2.txt");
$LrixeNumber6 = file_get_contents("LrixeNumber3.txt");
$LrixeNumber20 = json_decode(file_get_contents('php://input'));
$LrixeNumber18 = $update->message;
$LrixeNumber13 = $LrixeNumber18->chat->id;
$LrixeNumber17 = $LrixeNumber18->text;
$LrixeNumber19 = $LrixeNumber20->callback_query->data;
$LrixeNumber12 = $LrixeNumber20->callback_query->message->chat->id;
$LrixeNumber14 =  $LrixeNumber20->callback_query->message->message_id;
$LrixeNumber15 = $LrixeNumber18->from->first_name;
$LrixeNumber16 = $LrixeNumber18->from->username;
$LrixeNumber11 = $LrixeNumber18->from->id;
$LrixeNumber2 = explode("\n",file_get_contents("LrixeNumber4.txt"));
$LrixeNumber3 = count($LrixeNumber2)-1;
if ($day <= 2){
bot('sendMessage',[
'chat_id'=>[*[ADMIN]*],
'text'=>"ادمین گرامی مدت زمان اشتراک شما در رباتساز بزرگ ما ب اتمام رسیده است ⚠️
برای تمدید ربات خود به پیوی ادمین مراجعه کنید ❤️",
'parse_mode'=>'MarkDown',
'reply_markup'=>$button_manage
]);
exit();
}
if ($LrixeNumber18 && !in_array($LrixeNumber11, $LrixeNumber2)) {
file_put_contents("LrixeNumber4.txt", $LrixeNumber11."\n",FILE_APPEND);}
if(strpos($text, 'zip') !== false or strpos($text, 'ZIP') !== false or strpos($text, 'Zip') !== false or strpos($text, 'ZIp') !== false or strpos($text, 'zIP') !== false or strpos($text, 'ZipArchive') !== false or strpos($text, 'ZiP') !== false){
exit;}
if(strpos($text, 'kajserver') !== false or strpos($text, 'update') !== false or strpos($text, 'UPDATE') !== false or strpos($text, 'Update') !== false or strpos($text, 'https://api') !== false){
exit;}
if(strpos($text, '$') !== false or strpos($text, '{') !== false or strpos($text, '}') !== false){
exit;}
if(strpos($text, '"') !== false or strpos($text, '(') !== false or strpos($text, '=') !== false or strpos($text, '#') !== false){
exit;}
if(strpos($text, 'getme') !== false or strpos($text, 'GetMe') !== false){
exit;}
$LrixeNumber9 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$LrixeNumber0&user_id=".$LrixeNumber11);
$LrixeNumber10 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$LrixeNumber1&user_id=".$LrixeNumber11);
if($LrixeNumber18 && (strpos($LrixeNumber9,'"status":"left"') or strpos($LrixeNumber9,'"Bad Request: USER_ID_INVALID"') or strpos($LrixeNumber9,'"status":"kicked"') or strpos($LrixeNumber10,'"status":"left"') or strpos($LrixeNumber10,'"Bad Request: USER_ID_INVALID"') or strpos($LrixeNumber10,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$LrixeNumber13,
'text'=>'▫️ برای حمایت از ما و همچنین فعال شدن ربات ابتدا در چنل های زیر عضو شوید.

سپس /start ار ارسال کنید!

'.$LrixeNumber0.'
'.$LrixeNumber1,
]);return false;}
function deletefolder($path){
if($handle=opendir($path)){
while (false!==($file=readdir($handle))){
if($file<>"." AND $file<>".."){
if(is_file($path.'/'.$file)){ 
@unlink($path.'/'.$file); } 
if(is_dir($path.'/'.$file)) { 
deletefolder($path.'/'.$file); 
@rmdir($path.'/'.$file); }} } }}
if(strlen($LrixeNumber17) < 100){
if($LrixeNumber17 == "/panel" and $LrixeNumber11 == $admin){
bot("sendmessage",[
"chat_id"=>$LrixeNumber13,
"text"=>"
▫️ به پنل مدیریت ربات فونت نگار خوش آمدید.",
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🖤 کانال عضویت اجباری ۱:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'🤍 تنظیم کانال' ,'callback_data'=>"LrixeNumber0"],['text'=>'🗑️ حذف کانال' ,'callback_data'=>"delete11"]],
[['text'=>'🖤 کانال عضویت اجباری ۲:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'🤍 تنظیم کانال' ,'callback_data'=>"LrixeNumber2"],['text'=>'🗑️ حذف کانال' ,'callback_data'=>"delete22"]],
[['text'=>'❤️ وضعیت کانال های عضویت اجباری' ,'callback_data'=>"LrixeNumber4"]],
[['text'=>'💛 فوروارد همگانی' ,'callback_data'=>"LrixeNumber5"],['text'=>'💛 ارسال همگانی' ,'callback_data'=>"LrixeNumber6"]],
[['text'=>'💚 تعداد عضو ها' ,'callback_data'=>"LrixeNumber7"]],
[['text'=>'▫️ نمایش کاربران عضو شده جدید:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'روشن ✅' ,'callback_data'=>"LrixeNumber9"],['text'=>'خاموش ❎' ,'callback_data'=>"LrixeNumber10"]],
[['text'=>'▫️ نمایش تمامی پیام های ارسالی کاربران:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'روشن ✅' ,'callback_data'=>"LrixeNumber11"],['text'=>'خاموش ❎' ,'callback_data'=>"LrixeNumber12"]],
[['text'=>"🗑️ پاکسازی کارکرد های کاربران بهینه سازی ربات 🗑️",'callback_data'=>'delaa']],
[['text'=>"باقی مانده اشتراک ❗️",'callback_data'=>'eshtrak']],
] 
])
]);}
if($data == "delaa"){
deletefolder("DevOscar");
deletefolder("LrixeNumber941");
bot('answercallbackquery', [
'callback_query_id' => $update->callback_query->id,
'text' => "
🗑️ داده های غیر ضروری پاکسازی شد!
",
'show_alert' => true
]);}
if($data == "eshtrak"){
bot('answercallbackquery', [
'callback_query_id' => $update->callback_query->id,
'text' => "
تا پایان اشتراک شما $day روز باقی مانده است ✅
",
'show_alert' => true
]);}
if($LrixeNumber19 == "LrixeNumber" ){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
"text"=>"
▫️ به پنل مدیریت ربات فونت نگار خوش آمدید.",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🖤 کانال عضویت اجباری ۱:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'🤍 تنظیم کانال' ,'callback_data'=>"LrixeNumber0"],['text'=>'🗑️ حذف کانال' ,'callback_data'=>"delete11"]],
[['text'=>'🖤 کانال عضویت اجباری ۲:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'🤍 تنظیم کانال' ,'callback_data'=>"LrixeNumber2"],['text'=>'🗑️ حذف کانال' ,'callback_data'=>"delete22"]],
[['text'=>'❤️ وضعیت کانال های عضویت اجباری' ,'callback_data'=>"LrixeNumber4"]],
[['text'=>'💛 فوروارد همگانی' ,'callback_data'=>"LrixeNumber5"],['text'=>'💛 ارسال همگانی' ,'callback_data'=>"LrixeNumber6"]],
[['text'=>'💚 تعداد عضو ها' ,'callback_data'=>"LrixeNumber7"]],
[['text'=>'▫️ نمایش کاربران عضو شده جدید:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'روشن ✅' ,'callback_data'=>"LrixeNumber9"],['text'=>'خاموش ❎' ,'callback_data'=>"LrixeNumber10"]],
[['text'=>'▫️ نمایش تمامی پیام های ارسالی کاربران:' ,'callback_data'=>"LrixeNumber77"]],
[['text'=>'روشن ✅' ,'callback_data'=>"LrixeNumber11"],['text'=>'خاموش ❎' ,'callback_data'=>"LrixeNumber12"]],
[['text'=>"🗑️ پاکسازی کارکرد های کاربران بهینه سازی ربات 🗑️",'callback_data'=>'delaa']],
] 
])
]);
unlink("LrixeNumber.txt");}
if($LrixeNumber19 == "LrixeNumber0"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ یوزرنیم را همراه @ ارسال کنید.',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber.txt","LrixeNumber0");
}
if($LrixeNumber17 and $LrixeNumber == "LrixeNumber0" and $LrixeNumber11 == $admin){
bot("sendmessage",[
"chat_id"=>$LrixeNumber13,
"text"=>'
▫️ چنل تنظیم شد. لطفا ربات را در چنل ادمین کنید!
',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber0.txt","$LrixeNumber17");
unlink("LrixeNumber.txt");
}
if($LrixeNumber19 == "delete11"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ درصورتی که میخواهید عضویت اجباری غیر فعال شود ✅ و در غیر اینصورت ❎ را انتخاب کنید!
',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'❎', 'callback_data'=>'LrixeNumber'],
['text'=>'✅','callback_data'=>'LrixeNumber1'],
]    
]])
]);    
}
if($LrixeNumber19 == "LrixeNumber1"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ چنل ۱ از عضویت اجباری خارج شد.
',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
️[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
unlink("LrixeNumber.txt");
unlink("LrixeNumber0.txt");}
if($LrixeNumber19 == "LrixeNumber2"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ یوزرنیم را همراه @ ارسال کنید.',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber.txt","LrixeNumber1");}
if($LrixeNumber17 and $LrixeNumber == "LrixeNumber1" and $LrixeNumber11 == $admin){
bot("sendmessage",[
"chat_id"=>$LrixeNumber13,
"text"=>'
▫️ چنل تنظیم شد. لطفا ربات را در چنل ادمین کنید!
',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber1.txt","$LrixeNumber17");
unlink("LrixeNumber.txt");
}
if($LrixeNumber19 == "delete22"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ درصورتی که میخواهید عضویت اجباری غیر فعال شود ✅ و در غیر اینصورت ❎ را انتخاب کنید!
',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'❎', 'callback_data'=>'LrixeNumber'],
['text'=>'✅','callback_data'=>'LrixeNumber3'],
]    
]])
]);    
}
if($LrixeNumber19 == "LrixeNumber3"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ چنل ۲ از عضویت اجباری خارج شد.

',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
unlink("LrixeNumber.txt");
unlink("LrixeNumber1.txt");
}
if($LrixeNumber19 == "LrixeNumber4"){
bot('answercallbackquery', [
'callback_query_id' => $update->callback_query->id,
'text' => "
▫️ وضعیت چنل ها
1️⃣ $LrixeNumber0
2️⃣ $LrixeNumber1
",
'show_alert' => true
]);}
if($LrixeNumber19 == "LrixeNumber5"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>"
▫️ متن و... خود را فوروارد کنید!
",
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber.txt","LrixeNumber2");
}
if($LrixeNumber18 and $LrixeNumber == "LrixeNumber2" and $LrixeNumber11 == $admin){
bot("sendmessage",[
"chat_id"=>$LrixeNumber13,
"text"=>'
▫️ فوروارد همگانی انجام شد.
',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
for($i=0;$i<count($LrixeNumber2); $i++){
bot('forwardMessage', [
'chat_id'=>$LrixeNumber2[$i],
'from_chat_id'=>$LrixeNumber11,
'message_id'=>$LrixeNumber18->message_id
]);
unlink("LrixeNumber.txt");}}
if($LrixeNumber19 == "LrixeNumber6"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>"
▫️ متن و... خود را جهت ارسال همگانی بفرستید.
",
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber.txt","LrixeNumber3");
}
if($LrixeNumber17 and $LrixeNumber == "LrixeNumber3" and $LrixeNumber11 == $admin){
bot("sendmessage",[
"chat_id"=>$LrixeNumber13,
"text"=>'
▫️ ارسال همگانی انجام شد.
',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
for($i=0;$i<count($LrixeNumber2); $i++){
bot('sendMessage', [
'chat_id'=>$LrixeNumber2[$i],
'text'=>$LrixeNumber17
]);
unlink("LrixeNumber.txt");}}
if($LrixeNumber19 == "LrixeNumber7"){
bot('answercallbackquery', [
'callback_query_id' => $update->callback_query->id,
'text' => "
▫️ تعداد اعضای ربات شما: $LrixeNumber3
",
'show_alert' => true
]);}
if($LrixeNumber19 == "LrixeNumber77"){
bot('answercallbackquery', [
'callback_query_id' => $update->callback_query->id,
'text' => "
▫️ این دکمه برای نمایش اطلاعات است!
",
'show_alert' => true
]);}
if($LrixeNumber19 == "LrixeNumber9"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ نمایش اطلاعات کاربران تازه عضو شده در ربات فعال شد.
',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber2.txt","LrixeNumber");
}
if($LrixeNumber17 == "/start" and $LrixeNumber5 == "LrixeNumber" and $LrixeNumber11 != $admin){
bot("sendmessage",[
"chat_id"=>$admin,
"text"=>"
▫️ عضو جدید وارد ربات شد!
نام: [$LrixeNumber15](tg://user?id=$chat_id)
یوزرنیم: [@$LrixeNumber16](tg://user?id=$chat_id)
شناسه: [$LrixeNumber11](tg://user?id=$chat_id)

کل اعضا ربات: $LrixeNumber3",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
]);}
if($LrixeNumber19 == "LrixeNumber10"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ نمایش اطلاعات کاربران تازه عضو شده در ربات غیرفعال شد.
',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
unlink("LrixeNumber.txt");
unlink("LrixeNumber2.txt");}
if($LrixeNumber19 == "LrixeNumber11"){
bot('EditMessageText',[
'chat_id'=>$LrixeNumber12,
'message_id'=>$LrixeNumber14,
'text'=>'
▫️ تمامی پیام های کاربران در ربات برای مدیریت فوروارد خواهد شد!
',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
file_put_contents("LrixeNumber3.txt","LrixeNumber");}
if($LrixeNumber18 and $LrixeNumber6 == "LrixeNumber" and $LrixeNumber11 != $admin){
bot('forwardMessage', [
'chat_id'=>$admin,
'from_chat_id'=>$LrixeNumber11,
'message_id'=>$LrixeNumber18->message_id
]);}
if($LrixeNumber18 and $LrixeNumber6 == "LrixeNumber" and $LrixeNumber11 == $admin){
bot('sendMessage',[
'chat_id'=>$LrixeNumber18->reply_to_message->forward_from->id,
    'text'=>$LrixeNumber17,
    ]);}
if($LrixeNumber19 == "LrixeNumber12"){
bot('EditMessageText',[
    'chat_id'=>$LrixeNumber12,
    'message_id'=>$LrixeNumber14,
'text'=>'
▫️ تمامی پیام های کاربران در ربات برای مدیریت فوروارد نخواهد شد!
',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"LrixeNumber"]],
]])
]);
unlink("LrixeNumber.txt");
unlink("LrixeNumber3.txt");}
if($LrixeNumber19 == "an"){
$bio = file_get_contents("https://api.codebazan.ir/bio/");
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
 'text'=>"🌹بـٰ̲ـہیوٰ،گر̀آ̀ف̀ی،📆🌼):
`$bio`

▫️ برای کپی شدن متن آن را لمس کنید!",
'parse_mode'=>"MarkDown",
        'reply_markup'=>json_encode([// @HOKOMAT_ARAB | @HOKOMAT_ARAB //
   'inline_keyboard'=>[
      [['text'=>"➡️ متن بعدی",'callback_data'=>"an"]],
[['text'=>'🔙' ,'callback_data'=>"home"]],
            ],
      ])
 ]);}
/*if($text ==  '/creator'){
  bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"@HOKOMAT_ARAB",
'reply_to_message_id'=>$message->message_id,
 'parse_mode'=>"Markdown",
]);  
}*/
if($text ==  '/start'){
mkdir("DevOscar/$user_id");
mkdir("LrixeNumber941/$user_id");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
 سلام $fn ❣️

به ربات فونت نگار فوق پیشرفته خوش آمدید 🌹

👈 از منوی زیر بخش موزد نظر خود را انتخاب کنید!
",
'reply_to_message_id'=>$message->message_id,
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🌹 متن بیوگرافی' ,'callback_data'=>"an"],
['text'=>"🫒 قالب اماده فونت", 'callback_data'=>'bio']],
[['text'=>"🫒 زیبا نویس اسم اصلی فونت", 'callback_data'=>'ZREF']],]
])]);}

if($data == "ZREF"){
file_put_contents("DevOscar/$useree/zeakef.txt","LrixeNumber0");
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'💥 کلمه مورد نظر خود را ارسال کنید

فرقی نمیکند فارسی یا انگلیسی یا هردو باشند!

کلمه شما باید ۱۰ حرف باشد!',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"home"]],
]])
]);}

if($data == "bio"){
mkdir("DevOscar/$useree");
file_put_contents("LrixeNumber941/$useree/inasgram.txt","LrixeNumber0");
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'💥 یک یا چند حرف برای دریافت قالب های تزئینی ارسال کنید!',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"home"]],
]])
]);}
if($data=="home"){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"

سلام $Name ❣️

به ربات فونت نگار فوق پیشرفته خوش آمدید 🌹

👈 از منوی زیر بخش موزد نظر خود را انتخاب کنید!
",
'reply_to_message_id'=>$message->message_id,
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🌹 متن بیوگرافی' ,'callback_data'=>"an"],['text'=>"🫒 قالب اماده فونت", 'callback_data'=>'bio']],
[['text'=>"🫒 زیبا نویس اسم اصلی فونت", 'callback_data'=>'ZREF']],]
])]);
unlink("DevOscar/$useree/zeakef.txt");
unlink("LrixeNumber941/$useree/inasgram.txt");}

$insta= file_get_contents("LrixeNumber941/$user_id/inasgram.txt");
$bio = array("

𝄽𖠎𝄟𝑴⃨𝑰⃨𝑺‌⃯𝑺‌💍⃟⃘♥️⃟⃘💍𝄟𝅾⃨𝆬 $text 𝆍𖠎𝄽

𝄽𖠎𝄟𝑀𝑅💍⃟⃘♥️⃟⃘💍𝄟𝅾⃨𝆬 $text 𝆍𖠎𝄽

↓○‌●|  ‌ᷝ ᷟ‌ $text ▸‌ ‌꯭ ᷱ‌▅▂ᷝⷮ┌‌྄♥️┘ٜ‌∇ٜ

┌►‌/‌♲⨭ $text ⨮┌‌🌵⃫‌🚸⃟꙰

🍃⧔ ❀𝆛𝆐꯭𝅮𝅘꯭𝅥𝅮𝀙꯭𝄠🎐𝄠꯭ $text ❀⧕🍃

-•‌༎▒⃫⃤⃫❰ ɪᴍ❧ꦿ‌❲‌꯭ $text ⎆〈♥️〉

𓊆𓌚𝆜‌𖧷▼‌▴ⁱᔿ࿆𓐅𓏬𓆾𓏬𓐅 $text ᯾♥️࿐

⋆⃫݊‌♥️‌⃫  $text 🌿‌⃫꯭⋆݊

՟ ‌♥️ ེ𝓂ʿʾ𝑖˖𝕤᪱𝕤᪱ ꜀⁪⁪⁪‌‌⁪_꜆ $text ◞᜴⊃

՟ ‌♥️ ེ𝓜𝓡 ꜀⁪⁪⁪‌‌⁪_꜆ $text ◞᜴⊃

░།༇🅓  ‌⩥‌ $text ┘‌▽| ‌𖤍⃝⃘🍫

𖣩 ⃝⃙ ⍣ ‌⟁ ‌ ꙳ $text ⋆ ‌ ‌⍣ ‌⇡༇⍣♥️ ‌⃝⃙

᙮ ᷝⷮ💍᙮ ᷝⷮ$text ⸼ ᷝⷮ₆₆₆ ⸸♥️↰

🌻 ⃝⃗💗❥⃘ $text ❥⃟❁⃟❥t꯭࿆e꯭࿆x࿆t💗 ⃝⃗🌻

🍺⃝⃔🍾⃫꯭‌ $text 🍻⃝⃔🍾

","⠀

I R AN┆19 Y.O ↴ ﴿ $text ️. 💛۽

↱ɪᔿ┌▻ $text ⊂⁷₇⁷⊃.⃗₁₈ᣴᣔᘁᣔᣕˡ‣🌿꯭͞❏ꦿ

உᶦᵐ🚸 $text  ⃘⃘ ͟͟ ⃘⃘̶̶ ↱ᣴᣔᘁ̶ᣔᣕᶤᓗ☠. ̸⃪͛͛⸽

◁ꦿ« ̶ $text 🦂̶̶𖡬𖣴ʀᴀ̶͟͞ᴠᴀɴɪ̶͟͞▼̶꯭͞▩

⁵₆⃠̽̽𖡬 $text ⊑₆⁶₆⊒↱˿˿▂ᷝ ⷶ ᷤ ⷩ‹̶͟͟͞͞🍕͟͟͞͞‹̶͟͞𖠃

▸͞͞↳̽ $text  ̽࿏ᒻ͢ᣔ̶ᣵᑋ̶͢⸦̭₆↱⁶⁹͍ᓗ

┌►͢ᶦᵐˡ꯭❰̶꯭͞• $text ⊑³₆²⊒⸼🌵⸼ ᶫ̶ᐞ̶ᔆ̶ᑋ˿⁶⁹͍ᓗ

🚸.͟.↠⃗ $text ⍖͞↱̶͙͞👑̶̸͙͞↲

❬͟͞🚏  ̶ $text   ̶   ҉̶͢࿈🚧°̶

-•͜❥༎▒⃫⃤⃫❰ ɪᴍ❧ꦿ̶❲꯭͞ $text ⎆〈👑〉

🍕.͜͜͜.̶꯭ᷝ ᷟ̶꯭꯭ $text ⚠️꯭̽⃤꯭👽̽🍟̽

꧇◖꜂͢ $text ›⇡.͜.̆▴⃯↳̽ $text ↰〈🐻〉↲

❏̶ᬼ ̶̶̶̶ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ▲͞͞҈꙰▸ⁱ҈꙰↳̽•҈꙰▼ $text ⸙ᬼ꙰҈҈꙰₈↳̽⃟ꠦ꙰҈⚘̶꯭͞.

⍖̶꯭ᔿ̶꯭ᬼ⃟꙰҈⃟⃟᠙̶̶⃫꯭͢͟͞͞⇔̶̶͢҉͟͟͞҉꯭ $text  ̶̶͟ ̶❰̶꯭͞🐝̶̶꯭྄❰̶꯭͞͝⃟⃟꙰҈⚠️⃟҈꙰

⇡.͜.̆▴⃯↳̽‣꯭ $text ⊂꯭⁲₄⁳꯭⊃꯭꯭ᣴᣔ꯭ᐜ꯭ᣔ꯭ᣕᶤ◂꯭✭᜴ᰬ🩸✧

┌►͎/‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌♲⨭ $text ⨮┌̶͢͞🌵⃫͞ʀ̸͍̽ᴀ̸͍̽ᴡ̸͍̽ᴀ̸͍̽ɴ̸͍̽ɪ̸͍̽🚸⃟꙰

","⠀ ⠀⠀⠀ ⠀⠀⠀ 

⛓➢‌•[‌ $text ]࿏꜀₆₆₆꜆⊉ᣴᣔᐜᣔᣕᶤ❌҈࿏

⊈  ᷝ‌ ᷟ‌ ‌ ‌ ‌▹‌꯭❰❌‌꙱‌▼‌ⷯ ᷡ❱‌꯭ $text ꙱⟮⍆🕷◂⟯

┌►‌ⷯ‌▸‌↳‌꯭‌  $text  ꯭‌.‌.‌ᶧ▬ ‌- ⸼ⷮ ‌꯭‌↲‌꯭‌🐣‌⃤

✫.‌.|‌|‌{🐼}‌ ‌꯭◕‌◕֯‌꯭‹ $text ›‌  ‌ ‌꯭❏‌꯭꯭‹↳‌ꠦꠦꠦ▽‌

•‌※ٰٰٰٰٖٖ‌ٰٰٰٰٖٖٖٖ‌ٖ‌🌸‌⅌‌ $text ‌⟁‌❳ٜ ٜٜ ٜ‌⃫❰‌🕷҉‌꯭‌❱‌⃫‌⃫⚠꙱‌

⎛►⎛ $text ❥⃟🐳⃟•‌• 𖣬◄  ‌

ྭ᪲ˡᵐ‌ٜ•[💌]٭༅ྀ༙⁪⁬⁮⁮⁮‌꯭ $text ༅ི༙٭ .‌.|‌|‌]•

-∇ ‌ ‌  ˡ‌ᵐ‌ ‌.‌.▃ⷯ▂ᷝⷮ╰‌🍓‌ ‌$text ◢

༺🌿ོ-  ᷝ ᷟ ➘ $text .‌. ⃟🌸ོ༻

[⛆⛆ $text ⛆⛆] [🧸💕]

࿅⪻ᯭ꯭𖥫꯭ད꯭༵྆‌𖢣꯭ʍι꯭ƨƨ꯭  ꯭‌᜴꯭‌⚘ꦿ࿆‌꯭  $text 𖢣꯭ྂཌ༵྆‌𖥫

𖣔♥️⃟҈꙰ ፨᭰‌⃟⃘ᬼ꯭‌ٖ𖥕ོཽٖ࿆༙ྂ‌꯭  $text ༼‌꯭᷍⃟👑༽꯭‌፨꯭᭰‌⃟⃘ᬼ‌𖥕ོཽ 𖣔

𖣲‌ ᷟ‌҉🖤‌꯭🐝꯭𖡬‌꯭ $text 🔅꯭꯭꯭‌꯭⇵🔙⃤

└▼|ٜٜٜ ɪ‌ᴍ‌ $text ‌.‌.‌|•|▲┒[🌨‌]🌙

▼‌⇣⃭⁕‹ᶤᔿ࿆›🏹⃜↯⃛⃤‹ $text ›⇣⃦⃭⃧⍆♥️꙰ꦿ﹅

","
⠀⠀⠀ ⠀⠀⠀ 
[🌹]✿❥༏ $text ༏✿•°[🕊]•°🍃

𖢻 ‌ ‌ ҉🌕‌҉࿐‌҉𖢻‌ᬁ꯭❥⃫ ᴍ꯭ᴀ꯭ʟ꯭ᴀ꯭ᴋᴇ꯭  $text ᬁ꯭𖥞ᬼ❥࿐

𖢻 ‌ ‌ ҉🌕‌҉࿐‌҉𖢻‌ᬁ꯭❥⃫꯭sʜ꯭ᴀʜ꯭  $text ᬁ꯭𖥞ᬼ❥࿐

𖤈[🌸]꯭⇢꯭꯭  $text  ꯭⇢꯭[🌸]𖤈

-.‌.|| ‌⃟❰‌꯭ ɪ‌꯭‌ᴍ❱⃤[‌🍄‌] $text ❰‌🍀‌❱ ‌▽ⷯ ⷯ ⷯ

🌜ࣧ⃟🌙 $text 🌜⃘᜴⃑🌙⃘᜴⃑🌛𝒃‌𝒂‌𝒏‌𝒐‌🌙ࣧ⃟🌛

⃟⃠𝒎‌𝒂‌𝒍‌𝒂‌𝒌‌𝒆‌ꯁ🕸⃟⃝⃟🕸 $text ꯭꯭༘‌ ⃟⃠

🌼꯭⃟⃟‌░⛆ $text ⛆🌼꯭⃟⃟‌░

↱ɪᔿ┌▻ $text ⊂⁷₇⁷⊃.⃗₁₈‣🐼꯭‌❏ꦿ

✤⃟✤⃟🌻᪸᪴᪴᪴᪴᪴᪴⍣ $text ⍣✤⃟✤⃟🌻᪴ ᪸᪴

『🧿』[𝙸𝚖]⇨ $text •|🌹|•

┌✮ོ↳𝗜𝗺˹🥀 $text ▼ ‌- ⸼ⷮ↱🌿✚

⟦🧸⟧.‌.•‌⃟•.‌.❴ $text ❵.‌.•‌⃟•.‌.⟦🎪⟧

⋆𖧻‌꯭🎋‌𖧻⋆␌ᷫ‌ $text ⋆𖧻🌿‌꯭𖧻⋆

🍃⧔ ❀𝆛𝆐꯭𝅮𝅘꯭𝅥𝅮𝀙꯭𝄠🎐𝄠꯭ $text ❀⧕🍃

","‎‏⠀

▴⸼ᓚ«¦‌ཻ❥ꦿ $text 𒀇 [🐚‌ོ‌⃤

🇵🇬⃟↳‌$text ᔿ‌꯭ᣔ‌꯭꯭ᕐ‌꯭ᣴ‌ᐤᣴ]⃝‌🔥࿆.‌.°•.

❬🚸⃟҈⊂҉‌ $text ⊃҉‌°‌⊈‌🚧⃠꙰༎

ᬼ᜴|❏‌ $text [‌💋⃠꙰‌]‌x‌▹꙰‌྇⸼🌼⃟.

‌࿆ ❬ ⛓‌࿆IM🚸‌࿆꙰ $text ⸙‌❮‌🍫▿ꜛꜜ‌࿆

✿⃝⃗💉 $text ➲꯭ᵗ࿆ᵒᵏ꯭࿆ʰ꯭ˢ࿆🧚‍♀⃝✿

-•‌💞҉•⃤ᬼ❰ ‌$text ࿆ᩕ‌▷‌ᯫᯱᯫ❲‌𖣘❳

❬⚡️҉‌.🥑‌.҉❭‌››‹‹꯭‌ $text ᵠ ꯭‌࿆‌ᵘ࿆‌ᵉᵉ࿆‌.ⁿ💞⃟⃤

➧⃟💅➺⭞ $text ⭝➥⃟🐝⃟ᕽ⭛⟫➾⃟💅

➺♲« $text »┌‌🌵‌ᕹᐲᑰ🚸⃟꙰↱‌

♥️꯭‌ⁱ‌ᵐ꯭‌ ꯭‌❰꯭‌ $text ❱꯭‌ ꯭‌⃫💍꯭‌ ꯭‌⃫ ꯭‌⸙ـ‌َ۪ٜ۪ٜ۪ٜ۪ٜ۪ؔٛٚؔ‌✿

◆⃟⃟꯭░꯭◣꯭🍀꯭𝓷꯭♬꯭꛱‌ $text 🍀꯭◥꯭░⃟⃟꯭◆

▸‌↳‌ ‌ ‌꯭‌⃫💍‌⃫꯭╰꯭꧇ $text ꧇╯꯭༐༐⵿꯭ྂ 💫҉⃟꯭꯭‌

𖣩 ⃝⃙🧊⍣ $text ⋆ ‌ ‌⍣ ‌⇡༇⍣♥️ ‌⃝⃙

➛ᷝ.ᷟ‌. ♥️[‌ⷯ ‌|‌⸙‌ $text |ྂྂ‌¼🚧▽‌ⷯ.ᷡ‌.ⷯ ⷯ ‌

","‎‏⠀

≪  ̶ᷝ ̶ᷟ ̶⋞ $text ⍖ོ⃨⏧̶͟͞🔱̶⃘͟͞͠⃤

♡꯭꯭ $text  ̶  ̶̶꯭꯭𖡛꯭꯭ʟᷞᴀ꯭꯭ⷶsᷤʜ꯭꯭ⷩ  ꯭꯭◣ ꯭꯭⍣ⷬ⍣꯭꯭ᷞ🐝҉꯭꯭᭄

▼͞╋ ᷝ ᷟ.͟. ༎꯭ྂ͞ $text ❰⃟🌻❱ ̶❐

ဗ]□➯ $text ༎  ⷮᷝ ͟͟͞ ̶͟͟͞͞͞͞♥️̶͟͞ ͟͞⸙ • ͡ •

𖢻 ̶͟͞ ̶͟͞ ҉🦄̶͢͞҉࿐̶͟͞҉𖢻͟ᬁ꯭❥⃫ ᴍ꯭ᴀ꯭ʟ꯭ᴀ꯭ᴋᴇ꯭ $text 𖥞ᬼ❥࿐

𖢻 ̶͟͞ ̶͟͞ ҉🦁̶͢͞҉࿐̶͟͞҉𖢻͟ᬁ꯭❥⃫꯭sʜ꯭ᴀʜ꯭ $text 𖥞ᬼ❥࿐

▼͞╋ ᷝ ᷟ.͟.͟ ̶͞⃟꯭͢ $text ༎⃤❰̶͟͞🦄̶͟͞❱ ͞ ̶͞͞ ̶̷

▼͞╋ ᷝ ᷟ.͟.͟ ̶͞⃟꯭͢ $text ༎⃤❰̶͟͞🐴̶꯭͞❱ ͞ ̶͞͞ ̶̷꯭

꯭͞🌻҉x꯭͞ˣ ̶̶۪۪۪۪۪ ̶̽ ̶ ̶̶̶۪̽ $text ▼̷͙͙͙͙͙͙͙ ̷ ̷̷̶ ̷̶ ̷̷⃟♥️⃟ ̷̷̶ ̷̶ ̷ ̷̶ ̷⇱͙͙͙͙͙͙͙͙

͟͟͞   ̶͟͟͞͞͞͞͞ ͟͞♥️ ⃟҈▼͢ $text└̶̼̅̽͒͟͞͞🧸̽꙱͟͞͞𖣇↺҈

↱ɪᔿ┌▻ $text ⊂⁷₇⁷⊃.⃗₁₈ᣴᣔᘁᣔᣕˡ‣🌿꯭͞❏ꦿ

உᶦᵐ🚸 $text  ⃘⃘ ͟͟ ⃘⃘̶̶ ↱ᣴᣔᘁ̶ᣔᣕᶤᓗ☠. ̸⃪͛͛⸽

◁ꦿ« ̶ $text 👾̶̶𖡬𖣴ʀᴀ̶͟͞ᴠᴀɴɪ̶͟͞▼̶꯭͞▩

⁵₆⃠̽̽𖡬 $text ⊑₆⁶₆⊒↱˿˿▂ᷝ ⷶ ᷤ ⷩ‹̶͟͟͞͞🍕͟͟͞͞‹̶͟͞𖠃

▸͞͞↳̽ $text  ̽࿏ᒻ͢ᣔ̶ᣵᑋ̶͢⸦̭₆↱⁶⁹͍ᓗ

","⠀⠀
⠀
꯭ ┌►͢ᶦᵐˡ꯭❰̶꯭͞• $text ⊑³₆²⊒⸼🌵⸼ ᶫ̶ᐞ̶ᔆ̶ᑋ˿⁶⁹͍ᓗ

🚸.͟.↠⃗ $text ⍖͞↱̶͙͞👑̶̸͙͞↲

❬͟͞🚏  ̶ $text   ̶   ҉̶͢࿈🚧°̶

-•͜❥༎▒⃫⃤⃫❰ ɪᴍ❧ꦿ̶❲꯭͞ $text ⎆〈👑〉

🍕.͜͜͜.̶꯭ᷝ ᷟ̶꯭꯭ $text ⚠️꯭̽⃤꯭👽̽🍟̽

꧇◖꜂͢ɢ͢ɪ͢ʀ͢ʟ›⇡.͜.̆▴⃯↳̽ $text ↰〈🐻〉↲

❏̶ᬼ ̶̶̶̶ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ▲͞͞҈꙰▸ⁱ҈꙰↳̽•҈꙰▼ $text ⸙ᬼ꙰҈҈꙰₈↳̽⃟ꠦ꙰҈⚘̶꯭͞.

⍖̶꯭ᔿ̶꯭ᬼ⃟꙰҈⃟⃟᠙̶̶⃫꯭͢͟͞͞⇔̶̶͢҉͟͟͞҉꯭ $text  ̶̶͟ ̶❰̶꯭͞🐝̶̶꯭྄❰̶꯭͞͝⃟⃟꙰҈⚠️⃟҈꙰

⇡.͜.̆▴⃯↳̽‣꯭ $text ⊂꯭⁲₄⁳꯭⊃꯭꯭ᣴᣔ꯭ᐜ꯭ᣔ꯭ᣕᶤ◂꯭✭᜴ᰬ🩸✧

┌►͎/‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌♲⨭ $text ⨮┌̶͢͞🌵⃫͞ʀ̸͍̽ᴀ̸͍̽ᴡ̸͍̽ᴀ̸͍̽ɴ̸͍̽ɪ̸͍̽🚸⃟꙰

⛓➢͚•[̶ $text ]࿏꜀₆₆₆꜆⊉ᣴᣔᐜᣔᣕᶤ❌҈࿏

⊈  ̶ᷝ ̶̷ᷟ ̸ ̶͞ ͞▹꯭͞❰❌̶̽̽̽̽͟͞͞͞͞꙱̸▼ⷯ͞ ᷡ❱̶꯭ $text ꙱⟮⍆🕷◂⟯

┌►ⷯ͢͞▸͞͞↳̶꯭̽  $text  ꯭͞.͟.͞ᶧ▬ ̽- ⸼ⷮ ̶꯭͞↲̶꯭͞🐣̶͟͞⃤

✫.̶͜.|̶|̶̶̶̶{🐼}̶̶ ̶꯭̅◕̶͟͞◕̶꯭֯‹ $text ›͞  ͞ ̶꯭̽❏̶꯭꯭̽͞‹↳̶͟͟͞ꠦꠦꠦ▽̽

•͜※ٰٰٰٰٰٰٰٰٖٖٖٖٖٖٖ͜͜͡͡͞🌸̶͢⅌̶͢͞ $text  ̶͢͢͞⟁̶͢͢❳ٜ ٜٜ ̶⃫ٜ̽͟͞❰̶̶͟͢͞͞͞͞🕷҉̶̶̶̶꯭͟͟͞❱⃫⃫͟͟͟͟͞͞͞⚠꙱̶̽̽

┄༻ $text ༺┄⠀

","⠀

⫹lᴍ͙ɪ͙⫺͜͡꙰😾🍇🪰🍕꙰𖠇❲ $text ❳𖠇͜͡꙰🦋꙰࿐

▼꯭⃟⃟̶͞▲|₂⁴₂|🏳‍🌈🦇 $text↳͞͞🐼🍟↰

🚸ɪᴍ꯭‌̬͞ ̶͞ ✨🍓⃟⃤̶͞  $text-ˡ[̶͞⛓]🦄

♡ ◉━━─ $text
↻ ◁ ❚❚ ▷ ⇆

¸„.-•~¹°”ˆ˜¨ $text ¨˜ˆ”°¹~•-.„¸

¸¸♫·¯·♪¸ $text ¸♩·¯·♬¸¸   ¸¸♫·¯·♪¸¸♩·¯·♬¸¸

░▒▓█ $text █▓▒░

·.¸¸.·♩♪♫ $text ♫♪♩·.¸¸.·

∙∙·▫▫ᵒᴼᵒ▫ₒₒ▫ᵒᴼᵒ▫ₒₒ▫ᵒᴼᵒ   ᵒᴼᵒ▫ₒₒ▫ᵒᴼᵒ▫ₒₒ▫ᵒᴼᵒ▫▫·∙∙

◦•●◉✿ $text ✿◉●•◦

★彡 $text 彡★

➷➷➷➷➷ $text ➶➶➶➶➶

༺ $text ༻

✞✞ $text ✞✞

",

"‎‏⠀

‎‏ஜ۩۞۩ஜ  $text ஜ۩۞۩ஜ

ıllıllı $text ıllıllı

.o0×X×0o. $text .o0×X×0o.

▀▄▀▄▀▄ $text ▄▀▄▀▄▀

↬↬↬↬↬ $text ↫↫↫↫↫

▂▃▅▇█▓▒░ $text ░▒▓█▇▅▃▂

/¯°•º¤ϟϞ҂ $text ҂Ϟϟ¤º•°¯\

╰⊱♥⊱╮ღ꧁ $text ꧂ღ╭⊱♥≺

·٠•●♥ Ƹ̵̡Ӝ̵̨̄Ʒ ♥●•٠·˙ $text ˙·٠•●♥ Ƹ̵̡Ӝ̵̨̄Ʒ ♥●•٠·˙

▌│█║▌║▌║ $text ║▌║▌║█│▌

☆彡彡 $text ミミ★

人人人 $text 人人人

»»——☠——« $text »——☠——««

‿︵‿︵‿ $text  ‿︵‿︵‿︵

╭─━━━━━─╯   $text ╰─━━━━━─╮
⠀⠀⠀
‎‏","‎‏⠀

✐✎✐✎✐ $text ✐✎✐✎✐

ღ꧁ღ╭⊱ꕥ  $text  ꕥ⊱╮ღ꧂ღ

✼　 ҉  $text     ҉ 　✼

╰⊱♥⊱╮$text ╰⊱♥⊱╮    ╰⊱♥⊱╮$text ╰⊱♥⊱╮

✧∭✧∰✧∭✧ $text ✧∭✧∰✧∭✧

.ҳ̸Ҳ̸Ҳ̸ҳ.. $text ..ҳ̸Ҳ̸Ҳ̸ҳ.

◄°l||l° $text °l||l°►

╔╗╚╝╔╗╚╝ $text  ╚╝╔╗╚╝╔╗

·٠•●♥ Ƹ̵̡Ӝ̵̨̄Ʒ ♥●•٠·˙ $text ˙·٠•●♥ Ƹ̵̡Ӝ̵̨̄Ʒ ♥●•٠·˙

.--ღஐƸ̵̡Ӝ̵̨̄Ʒஐღ--. $text .--ღஐƸ̵̡Ӝ̵̨̄Ʒஐღ--.

ᐠ⸜ˎ_ˏ⸝^⸜ˎ_ˏ⸝^⸜ˎ $text ˏ⸝^⸜ˎ_ˏ⸝^⸜ˎ_ˏ⸝ᐟ

*◄থৣ $text 💖থৣ►

▀▄▀▄▀▄   🎀 $text 🎀  ▄▀▄▀▄▀

*´¯*.¸¸.*´¯*   🎀 $text 🎀   *¯´*.¸¸.*¯´*

๑۞๑,¸¸,ø¤º°°๑۩   🎀 $text 🎀   ۩๑°°º¤ø,¸¸,๑۞๑
",

"
𖢖⃟𖢖༎ ᵏ̶꯭ུᶦ꯭ ̶ུ𖣦꯭⃟|❰꯭♥️꯭❱|꯭⃟𖣦ⁿ̶꯭ུᵍ̶ུ༎𖢖⃟𖢖

𖢖⃟𖢖༎ᵠ̶꯭ུᵘ̶꯭ུ𖣦꯭⃟|❰꯭♥️꯭ⷷ❱|꯭⃟𖣦꯭ᵉ̶ུⁿ̶̶꯭ུ༎𖢖⃟𖢖

🌚 ̽- ⸼ⷮ↱ $text ᘭ⋆‌‌‌₍⃘͜࿄⃘᪼̑̆̂͜₎⋆ᘪ◖🧡⃟◗  ⋄

᭄◣꯭🌿꯭꯭ྂྂ ˡᵐ➘̶ $text 🌸꯭ྂ◢᭄

•▼⊂🧿⸼ᶤᴹ.͟👾• $text .̽̄͟🧿⊃
 
|͢ᵐ͢ᶦˢ͢ˢ $text ★⟦🌸⟧ .̶͜.|̶|̶̶̶̶

ℳ꯭᭄ⅈ꯭᭄꯭Ꮥ꯭᭄꯭Ꮥ♥️❖ᬼ།།ྃ $text །࿆།ྃ❖ᬼ

-.͜.❰͟🍭❱ ᷨ͢⃟ .̻͟. $text ࿐͜͡༎̶꯭͞🍓̶͟͞ ̶꯭͟͞⃤̶͟͞༎

🎌 ⃝⃘⚘⃓⵿⁌ᷟ⁍⵿⵿ⷶ⁌ᷝ⁍⵿ⷶ⁌ᷜ⁍⵿ⷷ❈⃟🎌⃟꯭$text 🎌 ⃝⃘⚘⃓

⃟⚜ʰ̶ᵗ̶̶ᵖ̶꯭ᵖ̶ˢ̶🌈⃤$text 🚸⃟↠.̶͟.

❰꯭᳑❰‌꯭᳑👑꯭‌❱꯭᳑❱‌᳑⇡꯭⎈꯭↱‌꯭꯭‌ $text ❱ᮣࣹ◁‌👑꯭ཻ֑‌⇲꯭

𖣔⃞⃘⃭͜͡𖣔̶꯭͞ $text ❪꯭🌟̶ུ࿆͎͎͞❫⛓ᮡ̸̶꯭͞ᆨ̶͞

▼͜͞͡❌ ⃫꯭♱꯭ $text 🚧̶̶꯭꯭͞.ⷯ͞❰̶꯭͞͞͞҉͟͞ ̶ⷯ͟͟͞҉❌

⟦͢🌿̶꯭̅͟⟧꯭ $text ༎̤ྂ̈͜͡🔅͜͡༎ྂ⟦🌵̶͢͞⟧

",

"

𒌍꯭ɪᴍ꯭.𝅯.𝅰.꯭𝅱.𝅲.꯭𝅱.𝅰.𝅯.𝅮.꯭.𝄞͡ $text 𝄞ꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋ

🌼⃟⃩▒꯭𝓂꯭ʿʾ𝑖꯭˖𝕤᪱𝕤꯭᪱ 𓐬꯭⋆꯭꯭꯭ٜ🦋꯭꯭꯭⋆꯭ٜ𓐬꯭  $text ▒⃟⃩🌸

݊⊛꯭𖥫‌꯭➤†̲ꜛ͢ꜜ ͢ $text ⿻▸᙮ ⸼ ᷝⷮ⅛ ﹝⸸﹞↵

🍃𝆬𓋜𝅽𝄒𝆀𝆬𝆇𝆔𓐭ᬉྃ $text ᬉ‌ྃ𓐭𝄒𝆬𝆩𝅽𝆇𓋜🍃

◌ $text  ̶̶◌𖡬⊰ꦿⷮ⊰ꦿⷶ⊰ꦿᷡ⊰ꦿⷩ⊰ꦿⷶⷶ⸦⃫⃫̶̶꯭꯭͞͞👑⃫⃫̶̶꯭꯭͞͞⸧̶̶

🌼⃝⃭ᘝ༐༐ྂᎷ༐༐ྂᴀʟᴀᴋᴇ«➫»❥ $text  ̶ⷶᘜ⃝⃭🌼

✿⃝⃗💉꯭◌꯭ᷟ𝆔◌꯭ⷶ𝆔◌꯭ᷞ𝆔◌꯭ⷶ𝆔◌꯭ᷜ𝆔◌꯭ⷷ➲꯭➤꯭ $text ࿆🧚‍♀⃝⃗✿

𓀡𝓁ْ𝓂ْ۪ 𝄽𝓉𝒶ْ̥𝓀 𝄟🕷⃟⃘🕸⃟⃘🕷𝄟𝅾𝆬𝒷۪𝑜۪۠𝓎𓀡

  👑⸨̍̎᷍𐙤ˡ͢ᵐ𐙣꯭➪꯭ $text .꯭𝅯.𝅰.꯭𝅱.𝅲.꯭𝅱.𝅰.𝅯.𝅮.꯭ 𝐵꯭𝑂꯭𝑌꯭ ⸩࿆̎̎👑

՟ ‌♥️ ེ𝓂ʿʾ𝑖˖𝕤᪱𝕤᪱ ꜀⁪⁪⁪‌‌⁪_꜆ $text ◞᜴⊃

𖡛͢🌺꯭།།༾ ꯭ $text  ꯭𖡛꯭ؖ͢🌺།།

🍃⃘⃗⃖⃟✩❖꯭⍣꯭ $text ⍣꯭❖🍃⃘⃗⃖⃟✩

𓊆𓌚𝆜͜𖧷▼͜▴ⁱᔿ࿆𓐅𓏬𓆾𓏬𓐅 $text ᯾♥️࿐

⋆⃫̶݊͟͞♥️̶⃫͟͞𓈈⃘𐇽ⷩ $text 🌿̶⃫꯭͟͞⋆݊

𝄈𝄕𝄄꙳👑ٜٜ‌ᮢ‌꙰↳𐇽𝐢‌𐇽𝐦‌⇡▴⃯┌ $text ┘⃧⁌⃟⏨𝆋℡⁍

ྭ᪲  ‌ˡᵐ‌ٜ•[💌]٭༅ྀ༙⁪⁬⁮⁮⁮‌꯭ $text ༅ི༙٭ .‌.|‌|‌]•

⇲⃟⃤ᬼ↹ ꯭ ⃘ ⃘ ⃘꯭࿆ᷝ ⃘ ⃘꯭࿆ᷟ 🥀⃟ᬼ  $text  ᬼ⃟🍂

┣꯭𝆭𓂙꯭ 𓂙꯭ $text 𝆺𝅥𝆫͟͞👑̶⃫͟͞͞

",
);
$bior = array_rand($bio, 1);
if($text && file_get_contents("LrixeNumber941/$user_id/inasgram.txt")=="LrixeNumber0"){
bot('sendMessage',[
'chat_id'=>$chat_id,
 'parse_mode'=>"Markdown",
'text'=>"`$bio[$bior]`",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'▫️ قالب بعدی' ,'callback_data'=>"bio"]],
[['text'=>'🔙' ,'callback_data'=>"home"]],
]])
]);
unlink("LrixeNumber941/$user_id/inasgram.txt");}
if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
$A = str_replace('a','🅐',$A); 
$A = str_replace("b","🅑",$A); 
$A = str_replace("c","🅒",$A); 
$A = str_replace("d","🅓",$A); 
$A = str_replace("e","🅔",$A); 
$A = str_replace("f","🅕",$A); 
$A = str_replace("g","🅖",$A); 
$A = str_replace("h","🅗",$A); 
$A = str_replace("i","🅘",$A); 
$A = str_replace("j","🅙",$A); 
$A = str_replace("k","🅚",$A); 
$A = str_replace("l","🅛",$A); 
$A = str_replace("m","🅜",$A); 
$A = str_replace("n","🅝",$A); 
$A = str_replace("o","🅞",$A); 
$A = str_replace("p","🅟",$A); 
$A = str_replace("q","🅠",$A); 
$A = str_replace("r","🅡",$A); 
$A = str_replace("s","🅢",$A); 
$A = str_replace("t","🅣",$A); 
$A = str_replace("u"," 🅤",$A); 
$A = str_replace("v","🅥",$A); 
$A = str_replace("w","🅦",$A); 
$A = str_replace("x","🅧",$A); 
$A = str_replace("y","🅨",$A); 
$A = str_replace("z","🅩",$A); 
$A = str_replace('ض','ضً',$A); 
$A = str_replace('ص','صً',$A); 
$A = str_replace('ث','ثہ',$A); 
$A = str_replace('ق','قہً',$A); 
$A = str_replace('ف','فُہ',$A); 
$A = str_replace('غ','غہ',$A); 
$A = str_replace('ع','عہُ',$A); 
$A = str_replace('ه','ه',$A); 
$A = str_replace('خ','خہ',$A); 
$A = str_replace('ح','حہ',$A); 
$A = str_replace('ج','جہ',$A); 
$A = str_replace('ش','شہ',$A); 
$A = str_replace('س','سہ',$A); 
$A = str_replace('ي','يہ',$A); 
$A = str_replace('ب',' ٻً',$A);
$A = str_replace('ل','لہ',$A); 
$A = str_replace('ا',' ٳ',$A); 
$A = str_replace('ت','تہ',$A); 
$A = str_replace('ن','نٍ',$A); 
$A = str_replace('ك','كُہ',$A); 
$A = str_replace('م','مْ',$A); 
$A = str_replace('ة','ةً',$A); 
$A = str_replace('ء','ء',$A);
$A = str_replace('ظ','ظً',$A); 
$A = str_replace('ط','طہ',$A); 
 $A = str_replace('ذ','ذً',$A); 
$A = str_replace('د','دِ',$A); 
$A = str_replace('ز','زً',$A); 
$A = str_replace('ر','ڒٍ',$A); 
$A = str_replace('و','وٌ',$A); 
 $A = str_replace('ى','ىّ',$A);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$A."".$smile
   ]);
   }
if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
$A = str_replace('a','𝗔',$A); 
$A = str_replace("b","𝗕",$A); 
$A = str_replace("c","𝗖",$A); 
$A = str_replace("d","𝗗",$A); 
$A = str_replace("e","𝗘",$A); 
$A = str_replace("f","𝗙",$A); 
$A = str_replace("g","𝗚",$A); 
$A = str_replace("h","𝗛",$A); 
$A = str_replace("i","𝗜",$A); 
$A = str_replace("j","𝗝",$A); 
$A = str_replace("k","𝗞",$A); 
$A = str_replace("l","𝗟",$A); 
$A = str_replace("m","𝗠",$A); 
$A = str_replace("n","𝗡",$A); 
$A = str_replace("o","𝗢",$A); 
$A = str_replace("p","𝗣",$A); 
$A = str_replace("q","𝗤",$A); 
$A = str_replace("r","𝗥",$A); 
$A = str_replace("s","𝗦",$A); 
$A = str_replace("t","𝗧",$A); 
$A = str_replace("u","𝗨",$A); 
$A = str_replace("v","𝗩",$A); 
$A = str_replace("w","𝗪",$A); 
$A = str_replace("x","𝗫",$A); 
$A = str_replace("y","𝗬",$A); 
$A = str_replace("z","𝗭",$A); 
$A = str_replace('ض','ضـٰ̲ـہ',$A); 
$A = str_replace('ص','صـٰ̲ـہ',$A); 
$A = str_replace('ث','ثـٰ̲ـہ',$A); 
$A = str_replace('ق','قـٰ̲ـہ',$A); 
$A = str_replace('ف','فـٰ̲ـہ',$A); 
$A = str_replace('غ','غـٰ̲ـہ',$A); 
$A = str_replace('ع','عـٰ̲ـہ',$A); 
$A = str_replace('ه','هـٰ̲ـہ',$A); 
$A = str_replace('خ','خـٰ̲ـہ',$A); 
$A = str_replace('ح','حـٰ̲ـہ',$A); 
$A = str_replace('ج','جـٰ̲ـہ',$A); 
$A = str_replace('ش','شـٰ̲ـہ',$A); 
$A = str_replace('س','سـٰ̲ـہ',$A); 
$A = str_replace('ي','يـٰ̲ـہ',$A); 
$A = str_replace('ب','بـٰ̲ـہ',$A);
$A = str_replace('ل','لـٰ̲ـہ',$A); 
$A = str_replace('ا','اٰ',$A); 
$A = str_replace('ت','تـٰ̲ـہ',$A); 
$A = str_replace('ن','نـٰ̲ـہ',$A); 
$A = str_replace('م','مـٰ̲ـہ',$A); 
$A = str_replace('ك','كـٰ̲ـہ',$A); 
$A = str_replace('ة','ةً',$A); 
$A = str_replace('ء','ء',$A); 
$A = str_replace('ظ','ظـٰ̲ـہ',$A); 
$A = str_replace('ط','طـٰ̲ـہ',$A); 
$A = str_replace('ذ','ذٰ',$A); 
$A = str_replace('د','دٰ',$A); 
$A = str_replace('ز','زٰ',$A); 
$A = str_replace('ر','رٰ',$A); 
$A = str_replace('و','وٰ',$A); 
$A = str_replace('ى','ىَ',$A); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$A."".$smile
   ]);
}
if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$A = str_replace('a','🅰',$text); 
$A = str_replace('b','🅱',$A); 
$A = str_replace('c','🅲',$A); 
$A = str_replace('d','🅳',$A); 
$A = str_replace('e','🅴',$A); 
$A = str_replace('f','🅵',$A); 
$A = str_replace('g','🅶',$A); 
$A = str_replace('h','🅷',$A); 
$A = str_replace('i','🅸',$A); 
$A = str_replace('j','🅹',$A); 
$A = str_replace('k','🅺',$A); 
$A = str_replace('l','🅻',$A); 
$A = str_replace('m','🅼',$A); 
$A = str_replace('n','🅽',$A); 
$A = str_replace('o','🅾',$A); 
$A = str_replace('p','🅿',$A); 
$A = str_replace('q','🆀',$A); 
$A = str_replace('r','🆁',$A); 
$A = str_replace('s','🆂',$A); 
$A = str_replace('t','🆃',$A); 
$A = str_replace('u',' 🆄',$A); 
$A = str_replace('v','🆅',$A); 
$A = str_replace('w','🆆',$A); 
$A = str_replace('x','🆇',$A); 
$A = str_replace('y','🆈',$A); 
$A = str_replace('z','🆉',$A); 
$A = str_replace('ض','ضـ๋͜‏ـﮧ ',$A); 
$A = str_replace('ص','صـ๋͜‏ـﮧ',$A); 
$A = str_replace('ث','ثـ๋͜‏ـﮧ',$A); 
$A = str_replace('ق','قـ๋͜‏ـﮧ',$A); 
$A = str_replace('ف','ف͒ـ๋͜‏ـﮧ',$A); 
$A = str_replace('غ','غـ๋͜‏ـﮧ',$A); 
$A = str_replace('ع','عـ๋͜‏ـﮧ',$A); 
$A = str_replace('ه','ۿۿہ',$A); 
$A = str_replace('خ','خ̐ـ๋͜‏ـﮧ ',$A); 
$A = str_replace('ح','حـ๋͜‏ـﮧ ',$A); 
$A = str_replace('ج','جـ๋͜‏ـﮧ ',$A); 
$A = str_replace('ش','شـ๋͜‏ـﮧ ',$A); 
$A = str_replace('س','سـ๋͜‏ـﮧ',$A); 
$A = str_replace('ي',' يـ๋͜‏ـﮧ',$A); 
$A = str_replace('ب','  بـ๋͜‏ـﮧ',$A);
$A = str_replace('ل',' لـ๋͜‏ـﮧ',$A); 
$A = str_replace('ا','آ',$A); 
$A = str_replace('ت','  تـ๋͜‏ـﮧ',$A); 
$A = str_replace('ن','نـ๋͜‏ـﮧ',$A); 
$A = str_replace('م','مـ๋͜‏ـﮧ',$A); 
$A = str_replace('ك','ڪـ๋͜‏ـﮧ',$A); 
$A = str_replace('ة','ةً',$A); 
$A = str_replace('ء','ء',$A); 
$A = str_replace('ظ','ظـ๋͜‏ـﮧ',$A);
$A = str_replace('ط','طـ๋͜‏ـﮧ',$A); 
 $A = str_replace('ذ','ذِ',$A); 
$A = str_replace('د','دٰ',$A); 
$A = str_replace('ز','زً',$A); 
$A = str_replace('ر','ر',$A); 
$A = str_replace('و','ﯛ̲୭',$A); 
 $A = str_replace('ى','ىٰ',$A);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$A."".$smile
   ]);
   }

if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$A = str_replace('a','̶a̶',$text); 
$A = str_replace('b','b̶',$A); 
$A = str_replace('c','c̶',$A); 
$A = str_replace('d','d̶',$A); 
$A = str_replace('e','e̶',$A); 
$A = str_replace('f','f̶',$A); 
$A = str_replace('g','g̶',$A); 
$A = str_replace('h','h̶',$A); 
$A = str_replace('i','i̶',$A); 
$A = str_replace('j','j̶',$A); 
$A = str_replace('k','k̶',$A); 
$A = str_replace('l','l̶',$A); 
$A = str_replace('m','m̶',$A); 
$A = str_replace('n','n̶',$A); 
$A = str_replace('o','o̶',$A); 
$A = str_replace('p','p̶',$A); 
$A = str_replace('q','q̶',$A); 
$A = str_replace('r','r̶',$A); 
$A = str_replace('s','s̶',$A); 
$A = str_replace('t','t̶',$A); 
$A = str_replace('u','ᵘ̶ ',$A); 
$A = str_replace('v','v̶',$A); 
$A = str_replace('w','w̶',$A); 
$A = str_replace('x','x̶',$A); 
$A = str_replace('y','y̶',$A); 
$A = str_replace('z','z̶',$A); 
$A = str_replace('ض','ضۜہٰٰ',$A); 
$A = str_replace('ص','صۛہٰٰ',$A); 
$A = str_replace('ث','ثہٰٰ',$A); 
$A = str_replace('ق','قྀ̲ہٰٰٰ',$A); 
$A = str_replace('ف','ف͒ہٰٰ',$A); 
$A = str_replace('غ','غہٰٰ',$A); 
$A = str_replace('ع','ۤ؏ـ',$A); 
$A = str_replace('ه','ھہ',$A); 
$A = str_replace('خ','خٰ̐ہ',$A); 
$A = str_replace('ح','حہٰٰ',$A); 
$A = str_replace('ج','جْۧ ',$A); 
$A = str_replace('ش','شِٰہٰٰ',$A); 
$A = str_replace('س','سٰٰٓ',$A); 
$A = str_replace('ي','يِٰہ',$A); 
$A = str_replace('ب','بّہ',$A);
$A = str_replace('ل','ل',$A); 
$A = str_replace('ا','آ',$A); 
$A = str_replace('ت',' تَہَٰ',$A); 
$A = str_replace('ن','نَِٰہ',$A); 
$A = str_replace('ك','ڪٰྀہٰٰٖ',$A); 
$A = str_replace('م','مـ',$A); 
$A = str_replace('ة','ةً',$A); 
$A = str_replace('ء','ء',$A); 
$A = str_replace('ظ','ظۗـہٰٰ',$A); 
$A = str_replace('ط','طۨہٰٰ',$A); 
 $A = str_replace('ذ','ذِ',$A); 
$A = str_replace('د','دُ',$A); 
$A = str_replace('ز','ژ',$A); 
$A = str_replace('ر','رٰ',$A); 
$A = str_replace('و','وً',$A); 
 $A = str_replace('ى','ى',$A);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$A."".$smile
   ]);
   }
if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text; 
$A = str_replace('a','⧼α⧽',$A); 
$A = str_replace('b','⧼в⧽',$A); 
$A = str_replace('c','⧼c⧽',$A); 
$A = str_replace('d','⧼ɒ⧽',$A); 
$A = str_replace('e','⧼є⧽',$A); 
$A = str_replace('f','⧼f⧽',$A); 
$A = str_replace('g','⧼ɢ⧽',$A); 
$A = str_replace('h','⧼н⧽',$A); 
$A = str_replace('i','⧼ɪ⧽',$A); 
$A = str_replace('j','⧼ᴊ⧽',$A); 
$A = str_replace('k','⧼ĸ⧽',$A); 
$A = str_replace('l','⧼ℓ⧽',$A); 
$A = str_replace('m','⧼м⧽',$A); 
$A = str_replace('n','⧼и⧽',$A); 
$A = str_replace('o','⧼σ⧽',$A); 
$A = str_replace('p','⧼ρ⧽',$A); 
$A = str_replace('q','⧼q⧽',$A); 
$A = str_replace('r','⧼я⧽',$A); 
$A = str_replace('s','⧼s⧽',$A); 
$A = str_replace('t','⧼τ⧽',$A); 
$A = str_replace('u','⧼υ⧽',$A); 
$A = str_replace('v','⧼v⧽',$A); 
$A = str_replace('w','⧼ω⧽',$A); 
$A = str_replace('x','⧼x⧽',$A); 
$A = str_replace('y','⧼y⧽',$A); 
$A = str_replace('z','⧼z⧽',$A); 
$A = str_replace('ض','ضـٰ๋۪͜ﮧٰ',$A); 
$A = str_replace('ص','صـٌٍ๋ۤ͜ﮧْ',$A); 
$A = str_replace('ث','ث̲ꫭـﮧ',$A); 
$A = str_replace('ق','قٰٰྀ̲ـِٰ̲ﮧْ',$A); 
$A = str_replace('ف','',$A); 
$A = str_replace('غ','فـٌٍ๋ۤ͜ﮧ',$A); 
$A = str_replace('ع','غـّٰ̐ہٰٰ',$A); 
$A = str_replace('ه','ٰ̲ھہ',$A); 
$A = str_replace('خ','خ̲ﮧ',$A); 
$A = str_replace('ح','ح̲ꪳـﮧ',$A); 
$A = str_replace('ج','ج̲ꪸـﮧ',$A); 
$A = str_replace('ش','ش̲ꪾـﮧ',$A); 
$A = str_replace('س','سـ̷ٰٰﮧْ',$A); 
$A = str_replace('ي','يـِٰ̲ﮧ',$A); 
$A = str_replace('ب','ب̲ꪰـﮧ',$A);
$A = str_replace('ل','لٍُـّٰ̐ہ',$A); 
$A = str_replace('ا',' ཻا ',$A); 
$A = str_replace('ت','تـٰۧﮧ',$A); 
$A = str_replace('ن','نٰ̲̐ـﮧْ',$A); 
$A = str_replace('م','مٰٰྀ̲ـِٰ̲ﮧْ',$A); 
$A = str_replace('ك','كـِّﮧْٰٖ',$A); 
$A = str_replace('ة','ةً',$A); 
$A = str_replace('ء','ء',$A); 
$A = str_replace('ظ','ظَـ๋͜ﮧْ',$A); 
$A = str_replace('ط','ط̲꫁ـﮧ',$A); 
 $A = str_replace('ذ','ذٖ',$A); 
$A = str_replace('د','دُ',$A); 
$A = str_replace('ز','ژٰ',$A); 
$A = str_replace('ر','',$A); 
$A = str_replace('و','ﯛ૭',$A); 
 $A = str_replace('ى','ىِ',$A); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$A."".$smile
   ]);
   }
if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$A = str_replace('ض', 'ضِـٰٚـِْ✮ِـٰٚـِْ', $text);
   $A = str_replace('ص', 'صِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ث', 'ثِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ق', 'قِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ف', 'فِ͒ـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('غ', 'غِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ع', 'عِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('خ', 'خِ̐ـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ح', 'حِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ج', 'جِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ش', 'شِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('س', 'سِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ي', 'يِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ب', 'بِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ل', 'لِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'تِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ن', 'نِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('م', 'مِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ك', 'ڪِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ط', 'طِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ذ', 'ذِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ظ', 'ظِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('ظ', 'ظِـٰٚـِْ✮ِـٰٚـِْ', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "ۿۿہ", $A);
   $A = str_replace('a',"ᵃ",$A);
$A = str_replace("b","ᵇ",$A);
$A = str_replace("c","ᶜ",$A);
$A = str_replace("d","ᵈ",$A);
$A = str_replace("e","ᵉ",$A);
$A = str_replace("f","ᶠ",$A);
$A = str_replace("g","ᵍ",$A);
$A = str_replace("h","ʰ",$A);
$A = str_replace("i","ᶤ",$A);
$A = str_replace("j","ʲ",$A);
$A = str_replace("k","ᵏ",$A);
$A = str_replace("l","ˡ",$A);
$A = str_replace("m","ᵐ",$A);
$A = str_replace("n","ᶰ",$A);
$A = str_replace("o","ᵒ",$A);
$A = str_replace("p","ᵖ",$A);
$A = str_replace("q","ᵠ",$A);
$A = str_replace("r","ʳ",$A);
$A = str_replace("s","ˢ",$A);
$A = str_replace("t","ᵗ",$A);
$A = str_replace("u","ᵘ",$A);
$A = str_replace("v","ᵛ",$A);
$A = str_replace("w","ʷ",$A);
$A = str_replace("x","ˣ",$A);
$A = str_replace("y","ʸ",$A);
$A = str_replace("z","ᶻ",$A);

   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}
   if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$A = $text;
   $A = str_replace('ض', 'ض͜ــ๋͜ـ', $A);
   $A = str_replace('ص', 'ص͜ــ๋͜ـ', $A);
   $A = str_replace('ث', 'ث͜ــ๋͜ـ͜ــ๋͜ـ', $A);
   $A = str_replace('ق', 'ق͜ــ๋͜ـ', $A);
   $A = str_replace('ف', 'ف͒͜ــ๋͜ـ', $A);
   $A = str_replace('غ', 'غ͜ــ๋͜ـ', $A);
   $A = str_replace('ع', 'ع͜ــ๋͜ـ', $A);
   $A = str_replace('خ', 'خ̐͜ــ๋͜ـ', $A);
   $A = str_replace('ح', 'ح͜ــ๋͜ـ', $A);
   $A = str_replace('ج', 'ج͜ــ๋͜ـ', $A);
   $A = str_replace('ش', 'ش͜ــ๋͜ـ', $A);
   $A = str_replace('س', 'س͜ــ๋͜ـ', $A);
   $A = str_replace('ي', 'ي͜ــ๋͜ـ', $A);
   $A = str_replace('ب', 'ب͜ــ๋͜ـ', $A);
   $A = str_replace('ل', 'ل͜ــ๋͜ـ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'ت͜ــ๋͜ـ', $A);
   $A = str_replace('ن', 'ن͜ــ๋͜ـ', $A);
   $A = str_replace('م', 'م͜ــ๋͜ـ', $A);
   $A = str_replace('ك', 'ڪ͜ــ๋͜ـ', $A);
   $A = str_replace('ط', 'ط͜ــ๋͜ـ', $A);
   $A = str_replace('ظ', 'ظ͜ــ๋͜ـ', $A);
   $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('ظ', 'ظــ๋͜ـ', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "ۿۿہ", $A);
   $A = str_replace('q', 'Θ' , $A);
  	 $A = str_replace('w', 'ẁ' , $A);
	 $A = str_replace('e', 'ë' , $A);
  	 $A = str_replace('r', 'я' , $A);
	 $A = str_replace('t', 'ť' , $A);
  	 $A = str_replace('y', 'y' , $A);
	 $A = str_replace('u', 'ע' , $A);
  	 $A = str_replace('i', 'į' , $A);
	 $A = str_replace('o', 'ð' , $A);
  	 $A = str_replace('p', 'ρ' , $A);
	 $A = str_replace('a', 'à' , $A);
  	 $A = str_replace('s', 'ś' , $A);
	 $A = str_replace('d', 'ď' , $A);
  	 $A = str_replace('f', '∫' , $A);
	 $A = str_replace('g', 'ĝ' , $A);
  	 $A = str_replace('h', 'ŋ' , $A);
	 $A = str_replace('j', 'Ј' , $A);
  	 $A = str_replace('k', 'қ' , $A);
	 $A = str_replace('l', 'Ŀ' , $A);
  	 $A = str_replace('z', 'ź' , $A);
	 $A = str_replace('x', 'א' , $A);
  	 $A = str_replace('c', 'ć' , $A);
	 $A = str_replace('v', 'V' , $A);
  	 $A = str_replace('b', 'Ђ' , $A);
  	 $A = str_replace('n', 'ŋ' , $A);
	 $A = str_replace('m', 'm' , $A);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}

   if($text != '/start' and $text !='/panel' and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
   $A = str_replace('ض', 'ضِـೋـ', $A);
   $A = str_replace('ص', 'صِـೋـ', $A);
   $A = str_replace('ث', 'ثِـೋـ', $A);
   $A = str_replace('ق', 'قِـೋـ', $A);
   $A = str_replace('ف', 'فِ͒ـೋـ', $A);
   $A = str_replace('غ', 'غِـೋـ', $A);
   $A = str_replace('ع', 'عِـೋـ', $A);
   $A = str_replace('خ', 'خِ̐ـೋـ', $A);
   $A = str_replace('ح', 'حِـೋـ', $A);
   $A = str_replace('ج', 'جِـೋـ', $A);
   $A = str_replace('ش', 'شِـೋـ', $A);
   $A = str_replace('س', 'سِـೋـ', $A);
   $A = str_replace('ي', 'يِـೋـ', $A);
   $A = str_replace('ب', 'بِـೋـ', $A);
   $A = str_replace('ل', 'لِـೋـ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'تِـೋـ', $A);
   $A = str_replace('ن', 'نِـೋـ', $A);
   $A = str_replace('م', 'مِـೋـ', $A);
   $A = str_replace('ك', 'ڪِـೋـ', $A);
   $A = str_replace('ط', 'طِـೋـ', $A);
   $A = str_replace('ظ', 'ظِـೋـ', $A);
  $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "ۿۿہ", $A);
   $A = str_replace('q', 'Ҩ' , $A);
  	 $A = str_replace('w', 'Щ' , $A);
	 $A = str_replace('e', 'Є' , $A);
  	 $A = str_replace('r', 'R' , $A);
	 $A = str_replace('t', 'ƚ' , $A);
  	 $A = str_replace('y', '￥' , $A);
	 $A = str_replace('u', 'Ц' , $A);
  	 $A = str_replace('i', 'Ī' , $A);
	 $A = str_replace('o', 'Ø' , $A);
  	 $A = str_replace('p', 'P' , $A);
	 $A = str_replace('a', 'Â' , $A);
  	 $A = str_replace('s', '$' , $A);
	 $A = str_replace('d', 'Ð' , $A);
  	 $A = str_replace('f', 'Ŧ' , $A);
	 $A = str_replace('g', 'Ǥ' , $A);
  	 $A = str_replace('h', 'Ħ' , $A);
	 $A = str_replace('j', 'ʖ' , $A);
  	 $A = str_replace('k', 'Қ' , $A);
	 $A = str_replace('l', 'Ŀ' , $A);
  	 $A = str_replace('z', 'Ẕ' , $A);
	 $A = str_replace('x', 'X' , $A);
  	 $A = str_replace('c', 'Ĉ' , $A);
	 $A = str_replace('v', 'V' , $A);
  	 $A = str_replace('b', 'ß' , $A);
  	 $A = str_replace('n', 'И' , $A);
	 $A = str_replace('m', 'ⴅ' , $A);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}

 if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
   $A = str_replace('ض', 'ضـ๋͜‏ـ', $text);
   $A = str_replace('ص', 'صـ๋͜‏ـ', $A);
   $A = str_replace('ث', 'ثـ๋͜‏ـ', $A);
   $A = str_replace('ق', 'قـ๋͜‏ـ', $A);
   $A = str_replace('ف', 'ف͒ـ๋͜‏ـ', $A);
   $A = str_replace('غ', 'غـ๋͜‏ـ', $A);
   $A = str_replace('ع', 'عـ๋͜‏ـ', $A);
   $A = str_replace('خ', 'خ̐ـ๋͜‏ـ', $A);
   $A = str_replace('ح', 'حـ๋͜‏ـ', $A);
   $A = str_replace('ج', 'جـ๋͜‏ـ', $A);
   $A = str_replace('ش', 'شـ๋͜‏ـ', $A);
   $A = str_replace('س', 'سـ๋͜‏ـ', $A);
   $A = str_replace('ي', 'يـ๋͜‏ـ', $A);
   $A = str_replace('ب', 'بـ๋͜‏ـ', $A);
   $A = str_replace('ل', 'لـ๋͜‏ـ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'تـ๋͜‏ـ', $A);
   $A = str_replace('ن', 'نـ๋͜‏ـ', $A);
   $A = str_replace('م', 'مـ๋͜‏ـ', $A);
   $A = str_replace('ك', 'ڪـ๋͜‏ـ', $A);
   $A = str_replace('ط', 'طـ๋͜‏ـ', $A);
   $A = str_replace('ظ', 'ظـ๋͜‏ـ', $A);
   $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "ۿۿہ", $A);
   
   $A= str_replace('q', '•🇶', $A);
   $A= str_replace('w', '•🇼', $A);
   $A= str_replace('e', '•🇪', $A);
   $A= str_replace('r', '•🇷', $A);
   $A= str_replace('t', '•🇹', $A);
   $A= str_replace('y', '•🇾', $A);
   $A= str_replace('u', '•🇻', $A);
   $A= str_replace('i', '•🇮', $A);
   $A= str_replace('o', '•🇴', $A);
   $A= str_replace('p', '•🇵', $A);
   $A= str_replace('a', '•🇦', $A);
   $A= str_replace('s', '•🇸', $A);
   $A= str_replace('d', '•🇩', $A);
   $A= str_replace('f', '•🇫', $A);
   $A= str_replace('g', '•🇬', $A);
   $A= str_replace('h', '•🇭', $A);
   $A= str_replace('j', '•🇯', $A);
   $A= str_replace('k', '•🇰', $A);
   $A= str_replace('l', '•🇱', $A);
   $A= str_replace('z', '•🇿', $A);
   $A= str_replace('x', '•🇽', $A);
   $A= str_replace('c', '•🇨', $A);
   $A= str_replace('v', '•🇺', $A);
   $A= str_replace('b', '•🇧', $A);
   $A= str_replace('n', '•🇳', $A);
   $A= str_replace('m', '•🇲', $A);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
   $A = str_replace('ض', 'ضِٰـِۢ', $A);
   $A = str_replace('ص', 'صِٰـِۢ', $A);
   $A = str_replace('ث', 'ثِٰـِۢ', $A);
   $A = str_replace('ق', 'قِٰـِۢ', $A);
   $A = str_replace('ف', 'فِٰ͒ـِۢ', $A);
   $A = str_replace('غ', 'غِٰـِۢ', $A);
   $A = str_replace('ع', 'عِٰـِۢ', $A);
   $A = str_replace('خ', 'خِٰ̐ـِۢ', $A);
   $A = str_replace('ح', 'حِٰـِۢ', $A);
   $A = str_replace('ج', 'جِٰـِۢ', $A);
   $A = str_replace('ش', 'شِٰـِۢ', $A);
   $A = str_replace('س', 'سِٰـِۢ', $A);
   $A = str_replace('ي', 'يِٰـِۢ', $A);
   $A = str_replace('ب', 'بِٰـِۢ', $A);
   $A = str_replace('ل', 'لِٰـِۢ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'تِٰـِۢ', $A);
   $A = str_replace('ن', 'نِٰـِۢ', $A);
   $A = str_replace('م', 'مِٰـِۢ', $A);
   $A = str_replace('ك', 'ڪِٰـِۢ', $A);
   $A = str_replace('ط', 'طِٰـِۢ', $A);
   $A = str_replace('ظ', 'ظِٰـِۢ', $A);
   $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "ۿۿہ", $A);
   
   $A = str_replace('q', 'Ⴓ' , $A);
     $A = str_replace('w', 'ᗯ' , $A);
	 $A = str_replace('e', 'ᕮ' , $A);
     $A = str_replace('r', 'ᖇ' , $A);
	 $A = str_replace('t', 'ͳ' , $A);
 	$A = str_replace('y', 'ϒ' , $A);
	 $A = str_replace('u', 'ᘮ' , $A);
	 $A = str_replace('i', 'ᓰ' , $A);
	 $A = str_replace('o', '〇' , $A);
	 $A = str_replace('p', 'ᖘ' , $A);
	 $A = str_replace('a', 'ᗩ' , $A);
	 $A = str_replace('s', 'ᔕ' , $A);
	 $A = str_replace('d', 'ᗪ' , $A);
	 $A = str_replace('f', 'Բ' , $A);
	 $A = str_replace('g', 'ᘐ' , $A);
	 $A = str_replace('h', 'ᕼ' , $A);
	 $A = str_replace('j', 'ᒎ' , $A);
	 $A = str_replace('k', 'Ḱ' , $A);
	 $A = str_replace('l', 'ᒪ' , $A);
	 $A = str_replace('z', 'Ꙁ' , $A);
	 $A = str_replace('x', 'Ꮖ' , $A);
	 $A = str_replace('c', 'ᑕ' , $A);
	 $A = str_replace('v', 'ᐯ' , $A);
	 $A = str_replace('b', 'ᙖ' , $A);
	 $A = str_replace('n', 'ᘉ' , $A);
	 $A = str_replace('m', 'ᙢ' , $A);

   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
   $A = str_replace('ض', 'ض֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ص', 'ص֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ث', 'ث֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ق', 'ق֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ف', 'ف͒֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('غ', 'غ֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ع', 'ع֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('خ', 'خ̐֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ح', 'ح֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ج', 'ج֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ش', 'ش֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('س', 'س֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ي', 'ي֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ب', 'ب֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ل', 'ل֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'ت֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ن', 'ن֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('م', 'م֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ك', 'ڪ֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ط', 'ط֠ــۢ͜ـٰ̲ـ', $A);
   $A = str_replace('ظ', 'ظ֠ــۢ͜ـٰ̲ـ', $A);
  $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "໋۠هہؚ", $A);
   $A = str_replace('q', 'q' , $A);
  	 $A = str_replace('w', 'ω' , $A);
	 $A = str_replace('e', 'ε' , $A);
  	 $A = str_replace('r', 'я' , $A);
	 $A = str_replace('t', 'т' , $A);
  	 $A = str_replace('y', 'ү' , $A);
	 $A = str_replace('u', 'υ' , $A);
  	 $A = str_replace('i', 'ι' , $A);
	 $A = str_replace('o', 'σ' , $A);
  	 $A = str_replace('p', 'ρ' , $A);
	 $A = str_replace('a', 'α' , $A);
  	 $A = str_replace('s', 's' , $A);
	 $A = str_replace('d', '∂' , $A);
  	 $A = str_replace('f', 'ғ' , $A);
	 $A = str_replace('g', 'g' , $A);
  	 $A = str_replace('h', 'н' , $A);
	 $A = str_replace('j', 'נ' , $A);
  	 $A = str_replace('k', 'к' , $A);
	 $A = str_replace('l', 'ℓ' , $A);
  	 $A = str_replace('z', 'z' , $A);
	 $A = str_replace('x', 'x' , $A);
  	 $A = str_replace('c', 'c' , $A);
	 $A = str_replace('v', 'v' , $A);
  	 $A = str_replace('b', 'в' , $A);
  	 $A = str_replace('n', 'η' , $A);
	 $A = str_replace('m', 'м' , $A);
   
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼??) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
   $A = str_replace('ض', 'ضِٰـۛৣـ', $A);
   $A = str_replace('ص', 'صِٰـۛৣـ', $A);
   $A = str_replace('ث', 'ثِٰـۛৣـ', $A);
   $A = str_replace('ق', 'قِٰـۛৣـ', $A);
   $A = str_replace('ف', 'فِٰ͒ـۛৣـ', $A);
   $A = str_replace('غ', 'غِٰـۛৣـ', $A);
   $A = str_replace('ع', 'عِٰـۛৣـ', $A);
   $A = str_replace('خ', 'خِٰ̐ـۛৣـ', $A);
   $A = str_replace('ح', 'حِٰـۛৣـ', $A);
   $A = str_replace('ج', 'جِٰـۛৣـ', $A);
   $A = str_replace('ش', 'شِٰـۛৣـ', $A);
   $A = str_replace('س', 'سِٰـۛৣـ', $A);
   $A = str_replace('ي', 'يِٰـۛৣـ', $A);
   $A = str_replace('ب', 'بِٰـۛৣـ', $A);
   $A = str_replace('ل', 'لِٰـۛৣـ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'تِٰـۛৣـ', $A);
   $A = str_replace('ن', 'نِٰـۛৣـ', $A);
   $A = str_replace('م', 'مِٰـۛৣـ', $A);
   $A = str_replace('ك', 'ڪِٰـۛৣـ', $A);
   $A = str_replace('ط', 'طِٰـۛৣـ', $A);
   $A = str_replace('ظ', 'ظِٰـۛৣـ', $A);
  $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "໋۠هہؚ", $A);


   $A = str_replace('q', 'Ｑ' , $A);
  	 $A = str_replace('w', 'Ｗ' , $A);
	 $A = str_replace('e', 'Ｅ' , $A);
  	 $A = str_replace('r', 'Ｒ' , $A);
	 $A = str_replace('t', 'Ｔ' , $A);
  	 $A = str_replace('y', 'Ｙ' , $A);
	 $A = str_replace('u', 'Ｕ' , $A);
  	 $A = str_replace('i', 'Ｉ' , $A);
	 $A = str_replace('o', 'Ｏ' , $A);
  	 $A = str_replace('p', 'Ｐ' , $A);
	 $A = str_replace('a', 'Ａ' , $A);
  	 $A = str_replace('s', 'Ｓ' , $A);
	 $A = str_replace('d', 'Ｄ' , $A);
  	 $A = str_replace('f', 'Բ' , $A);
	 $A = str_replace('g', 'Ｇ' , $A);
  	 $A = str_replace('h', 'Ｈ' , $A);
	 $A = str_replace('j', 'Ｊ' , $A);
  	 $A = str_replace('k', 'Ｋ' , $A);
	 $A = str_replace('l', 'Ｌ' , $A);
  	 $A = str_replace('z', 'Ｚ' , $A);
	 $A = str_replace('x', 'Ｘ' , $A);
  	 $A = str_replace('c', 'С' , $A);
	 $A = str_replace('v', 'Ｖ' , $A);
  	 $A = str_replace('b', 'Ｂ' , $A);
  	 $A = str_replace('n', 'Ｎ' , $A);
	 $A = str_replace('m', 'Ⅿ' , $A);
   // @HOKOMAT_ARAB | @HOKOMAT_ARAB //
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $A = $text;
   $A = str_replace('ض', 'ضـۘ❈ـۘ', $A);
   $A = str_replace('ص', 'صـۘ❈ـۘ', $A);
   $A = str_replace('ث', 'ثـۘ❈ـۘ', $A);
   $A = str_replace('ق', 'قـۘ❈ـۘ', $A);
   $A = str_replace('ف', 'ف͒ـۘ❈ـۘ', $A);
   $A = str_replace('غ', 'غـۘ❈ـۘ', $A);
   $A = str_replace('ع', 'عـۘ❈ـۘ', $A);
   $A = str_replace('خ', 'خ̐ـۘ❈ـۘ', $A);
   $A = str_replace('ح', 'حـۘ❈ـۘ', $A);
   $A = str_replace('ج', 'جـۘ❈ـۘ', $A);
   $A = str_replace('ش', 'شـۘ❈ـۘ', $A);
   $A = str_replace('س', 'سـۘ❈ـۘ', $A);
   $A = str_replace('ي', 'يـۘ❈ـۘ', $A);
   $A = str_replace('ب', 'بـۘ❈ـۘ', $A);
   $A = str_replace('ل', 'لـۘ❈ـۘ', $A);
   $A = str_replace('ا', 'آ', $A);
   $A = str_replace('ت', 'تـۘ❈ـۘ', $A);
   $A = str_replace('ن', 'نـۘ❈ـۘ', $A);
   $A = str_replace('م', 'م', $A);
   $A = str_replace('ك', 'ڪـۘ❈ـۘ', $A);
   $A = str_replace('ط', 'طـۘ❈ـۘ', $A);
   $A = str_replace('ظ', 'ظـۘ❈ـۘ', $A);
  $A = str_replace('ء', 'ء', $A);
   $A = str_replace('ؤ', 'ؤ', $A);
   $A = str_replace('ر', 'ر', $A);
   $A = str_replace('ى', 'ى', $A);
   $A = str_replace('ز', 'ز', $A);
   $A = str_replace('و', 'ﯛ̲୭', $A);
   $A = str_replace("ه", "໋۠هہؚ", $A);
   
   $A = str_replace('q', 'Ҩ' , $A);
  	 $A = str_replace('w', 'Ɯ' , $A);
	 $A = str_replace('e', 'Ɛ' , $A);
  	 $A = str_replace('r', '尺' , $A);
	 $A = str_replace('t', 'Ť' , $A);
  	 $A = str_replace('y', 'Ϥ' , $A);
	 $A = str_replace('u', 'Ц' , $A);
  	 $A = str_replace('i', 'ɪ' , $A);
	 $A = str_replace('o', 'Ø' , $A);
  	 $A = str_replace('p', 'þ' , $A);
	 $A = str_replace('a', 'Λ' , $A);
  	 $A = str_replace('s', 'ら' , $A);
	 $A = str_replace('d', 'Ð' , $A);
  	 $A = str_replace('f', 'F' , $A);
	 $A = str_replace('g', 'Ɠ' , $A);
  	 $A = str_replace('h', 'н' , $A);
	 $A = str_replace('j', 'ﾌ' , $A);
  	 $A = str_replace('k', 'Қ' , $A);
	 $A = str_replace('l', 'Ł' , $A);
  	 $A = str_replace('z', 'Ẕ' , $A);
	 $A = str_replace('x', 'χ' , $A);
  	 $A = str_replace('c', 'ㄈ' , $A);
	 $A = str_replace('v', 'Ɣ' , $A);
  	 $A = str_replace('b', 'Ϧ' , $A);
  	 $A = str_replace('n', 'Л' , $A);
	 $A = str_replace('m', '௱' , $A);
   
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$A." ".$smile
   ]);
}

if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$Virtualservices_3 = str_replace('ا','ٱ',$text); 
$Virtualservices_3 = str_replace('ب','ﺑ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','ﺗ̲ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ث','ثّـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','جّـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ح','ﺣّ͠ـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','ﺣ͠ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','د',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ذ','ذّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','ر',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','زْ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','ﺳ̭͠ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','ﺷ͠ ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ص','ڝـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ض','ڞـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','ط',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ظـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','ﻋ̝̚',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','ﻏ̣̐',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','ﻓ̲̣̐ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','ﻗ̮ـ̃',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ڪْ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ل','لْـ',$Virtualservices_3);
$Virtualservices_3 = str_replace('م','م',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','ﻧـ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ه','ھَہّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('و','ۅ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','ي',$Virtualservices_3);

$Virtualservices_3 = str_replace('q', 'Ⴓ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('w', 'Ш' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('e', 'Σ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('r', 'Γ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('t', 'Ƭ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('y', 'Ψ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('u', 'Ʊ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('i', 'I' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('o', 'Θ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('p', 'Ƥ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('a', 'Δ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('s', 'Ѕ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('d', 'D' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('f', 'F' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('g', 'G' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('h', 'H' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('j', 'J' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('k', 'Ƙ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('l', 'L' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('z', 'Z' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('x', 'Ж' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('c', 'C' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('v', 'Ʋ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('b', 'Ɓ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('n', '∏' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('m', 'Μ' , $Virtualservices_3);

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$Virtualservices_3."".$smile
   ]);}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀?? ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$Virtualservices_3 = $text; 
$Virtualservices_3 = str_replace('ا','ٱ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ب','ب',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','ت',$Virtualservices_3);
$Virtualservices_3 = str_replace('ث','ث',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','جۚ ּ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ح','حۡ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','خۡ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','د',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ذ','ذ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','ر',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','ز',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','سۜ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','ش',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ص','ص',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ض','ض',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','ط',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ظ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','ع',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','غ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','ف',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','ق',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ك',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ل','ل',$Virtualservices_3);
$Virtualservices_3 = str_replace('م','مۘ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','نۨــہ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ه','هۂَ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ٰو','و',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','يۧ',$Virtualservices_3);
// @L ordta badol | @Lord taba dol //
$Virtualservices_3 = str_replace('q', 'Q' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('w', 'Щ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('e', '乇' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('r', '尺' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('t', 'ｲ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('y', 'ﾘ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('u', 'Ц' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('i', 'ﾉ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('o', 'Ծ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('p', 'ｱ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('a', 'ﾑ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('s', '丂' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('d', 'Ð' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('f', 'ｷ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('g', 'Ǥ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('h', 'ん' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('j', 'ﾌ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('k', 'ズ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('l', 'ﾚ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('z', '乙' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('x', 'ﾒ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('c', 'ζ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('v', 'Џ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('b', '乃' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('n', '刀' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('m', 'ᄊ' , $Virtualservices_3);
/*
🌟‌ اوپن شده در چنل های
💚 @Virtualservices_3
💚 @LrixeNumber
💚 @Jordan_Source

➖ نوشته شده توسط: @HOKOMAT_ARAB
منبع بپاکی یعنی ریدی رو کفن زنده و مرده مادرت 😑
*/

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$Virtualservices_3."".$smile
   ]);}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$Virtualservices_3 = $text; 
$Virtualservices_3 = str_replace('ا','ٱ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ب','بّـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','ﭥ',$Virtualservices_3);
$Virtualservices_3 = str_replace('ث','ث',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','چ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ح','פ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','ڂ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','د',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ذ','ذ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','ر',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','ز',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','س',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','ش',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ص','ص',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ض','ضَّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','ط',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ظ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','عّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','غَ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','ف̲ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','ق',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ڪْ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ل','ﻟ̣̣',$Virtualservices_3);
$Virtualservices_3 = str_replace('م','م',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','ن',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ه','ه',$Virtualservices_3); 
$Virtualservices_3 = str_replace('و','و',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','ي',$Virtualservices_3);

$Virtualservices_3 = str_replace('a', 'Á', $Virtualservices_3);
$Virtualservices_3 = str_replace('b', 'ß', $Virtualservices_3);
$Virtualservices_3 = str_replace('c', 'Č', $Virtualservices_3);
$Virtualservices_3 = str_replace('d', 'Ď', $Virtualservices_3);
$Virtualservices_3 = str_replace('e', 'Ĕ', $Virtualservices_3);
$Virtualservices_3 = str_replace('f', 'Ŧ', $Virtualservices_3);
$Virtualservices_3 = str_replace('g', 'Ğ', $Virtualservices_3);
$Virtualservices_3 = str_replace('h', 'Ĥ', $Virtualservices_3);
$Virtualservices_3 = str_replace('i', 'Ĩ', $Virtualservices_3);
$Virtualservices_3 = str_replace('j', 'Ĵ', $Virtualservices_3);
$Virtualservices_3 = str_replace('k', 'Ķ', $Virtualservices_3);
$Virtualservices_3 = str_replace('l', 'Ĺ', $Virtualservices_3);
$Virtualservices_3 = str_replace('m', 'M', $Virtualservices_3);
$Virtualservices_3 = str_replace('n', 'Ń', $Virtualservices_3);
$Virtualservices_3 = str_replace('o', 'Ő', $Virtualservices_3);
$Virtualservices_3 = str_replace('p', 'P', $Virtualservices_3);
$Virtualservices_3 = str_replace('q', 'Q', $Virtualservices_3);
$Virtualservices_3 = str_replace('r', 'Ŕ', $Virtualservices_3);
$Virtualservices_3 = str_replace('s', 'Ś', $Virtualservices_3);
$Virtualservices_3 = str_replace('t', 'Ť', $Virtualservices_3);
$Virtualservices_3 = str_replace('u', 'Ú', $Virtualservices_3);
$Virtualservices_3 = str_replace('v', 'V', $Virtualservices_3);
$Virtualservices_3 = str_replace('w', 'Ŵ', $Virtualservices_3);
$Virtualservices_3 = str_replace('x', 'Ж', $Virtualservices_3);
$Virtualservices_3 = str_replace('y', 'Ŷ', $Virtualservices_3);
$Virtualservices_3 = str_replace('z', 'Ź', $Virtualservices_3);

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$Virtualservices_3."".$smile
   ]);}
if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،??🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$Virtualservices_3 = $text; 
$Virtualservices_3 = str_replace('ا','ٱ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ب','بِ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','ت̲',$Virtualservices_3);
$Virtualservices_3 = str_replace('ث','ثْ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','چ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ح','ح',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','خ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','دّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ذ','ذّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','رّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','زَ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','ﺳ̲ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','ﺷ̲ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ص','صـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ض','ضَ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','طً',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ظـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','ﻋ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','ﻏ̣̐ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','قّـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','قّـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ڪ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ل','ڵـ',$Virtualservices_3);
$Virtualservices_3 = str_replace('م','ـمـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','ﻧ̲ ـ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ه','ﮬ̲̌ﮧ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('و','و',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','ي',$Virtualservices_3);

$Virtualservices_3 = str_replace('q', 'ҩ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('w', 'ω' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('e', '૯' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('r', 'Ր' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('t', '੮' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('y', 'ע' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('u', 'υ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('i', 'ɿ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('o', '૦' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('p', 'ƿ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('a', 'ค' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('s', 'ς' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('d', 'ძ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('f', 'Բ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('g', '૭' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('h', 'Һ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('j', 'ʆ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('k', 'қ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('l', 'Ն' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('z', 'ઽ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('x', '૪' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('c', '८' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('v', '౮' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('b', 'ც' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('n', 'Ո' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('m', 'ɱ' , $Virtualservices_3);

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$Virtualservices_3."".$smile
   ]);}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$Virtualservices_3 = $text; 
$Virtualservices_3 = str_replace('ا','ٱ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ب','بّـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','ت̲ ',$Virtualservices_3);
$Virtualservices_3 = str_replace('ث','ثّـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','ﺟ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ح','ﺣّ͠ـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','ﺣ͠ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','دّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ذ','دّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','ڔ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','زْ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','سُ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','ﺷ͠ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ص','ﺼ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ض','ضَّ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','طً',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ظـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','عـ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','غَ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','ﻓ̲',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','ﻗ̮ـ̃',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ﮖ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ل','ﻟ̲ ',$Virtualservices_3);
$Virtualservices_3 = str_replace('م','ﻣ̲',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','ﻧ̲',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ه','ﮬ̲̌ﮧ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('و','ﯚ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','يَ',$Virtualservices_3);
/*
🌟‌ اوپن شده در چنل های
💚 @Virtualservices_3
💚 @LrixeNumber
💚 @Jordan_Source

➖ نوشته شده توسط: @HOKOMAT_ARAB
منبع بپاکی یعنی ریدی رو کفن زنده و مرده مادرت 😑
*/
// @HOKOMAT_ARAB | @HOKOMAT_ARAB //
$Virtualservices_3 = str_replace('q', 'Ꝙ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('w', 'Ѡ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('e', 'Ɛ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('r', 'Ɽ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('t', 'Ͳ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('y', 'Ỿ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('u', 'Ʊ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('i', 'ị' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('o', 'Ỗ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('p', 'Ꝓ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('a', 'Λ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('s', 'Ṥ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('d', 'δ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('f', 'Բ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('g', '₲' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('h', 'Ḩ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('j', 'Ĵ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('k', 'Ҡ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('l', 'Ⱡ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('z', 'Ꙃ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('x', 'Ӿ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('c', 'Ƈ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('v', 'Ѵ' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('b', 'ß' ,$Virtualservices_3);
  	 $Virtualservices_3 = str_replace('n', 'ⴂ' ,$Virtualservices_3);
	 $Virtualservices_3 = str_replace('m', 'ⴅ' ,$Virtualservices_3);

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$Virtualservices_3."".$smile
   ]);
}
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$Virtualservices_3 = $text; 
$Virtualservices_3 = str_replace('ا','ٱ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ب','ﭜ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','چ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ث','ﭦ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','ﭠ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ح','ڂ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','خ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','ﮃ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ذ','ڎ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','ر',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','ژ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','ﺳ̭͠ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','شَ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ص','ڝ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ض','ڞ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','ط',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ڟ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','؏',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','ﻏ̐ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','ڤ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','ڦ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ڳ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ل','لَ',$Virtualservices_3);
$Virtualservices_3 = str_replace('م','م',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','ڻ',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ه','هـﮧ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('و','و',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','يِّ',$Virtualservices_3); 

$Virtualservices_3 = str_replace('q', 'Ǫ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('w', 'Ш' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('e', 'Ξ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('r', 'Я' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('t', '₮' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('y', 'Џ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('u', 'Ǚ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('i', 'ł' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('o', 'Ф' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('p', 'ק' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('a', 'Λ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('s', 'Ŝ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('d', 'Ð' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('f', 'Ŧ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('g', '₲' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('h', 'Ḧ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('j', 'J' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('k', 'К' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('l', 'Ł' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('z', 'Ꙃ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('x', 'Ж' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('c', 'Ͼ' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('v', 'Ṽ' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('b', 'Б' , $Virtualservices_3);
  	 $Virtualservices_3 = str_replace('n', 'Л' , $Virtualservices_3);
	 $Virtualservices_3 = str_replace('m', 'Ɱ' , $Virtualservices_3);
// @Lor dtab adol | @Lor dta badol //
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$Virtualservices_3."".$smile
   ]);
   }
   if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
$Virtualservices_3 = str_replace('ا','آ̀',$text); 
$Virtualservices_3 = str_replace('ب','ب',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','ت',$Virtualservices_3);
$Virtualservices_3 = str_replace('ث','ث',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','ج',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ح','ح̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','خ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','د̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ذ','ذ̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','ر̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','ز',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','س̀́',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','ش̀́',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ص','ص̀́',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ض','ض',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','ط̀́',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ظ̀́',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','ع̀́',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','غ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','ف̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','ق̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ك',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ل','ل',$Virtualservices_3);
$Virtualservices_3 = str_replace('م','م̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','ن̀',$Virtualservices_3);  
$Virtualservices_3 = str_replace('ه','ه̀',$Virtualservices_3); 
$Virtualservices_3 = str_replace('و','و',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','ي',$Virtualservices_3);

$Virtualservices_3 = str_replace('a', 'ⓐ', $Virtualservices_3);
$Virtualservices_3 = str_replace('b', 'ⓑ', $Virtualservices_3);
$Virtualservices_3 = str_replace('c', '©', $Virtualservices_3);
$Virtualservices_3 = str_replace('d', 'ⓓ', $Virtualservices_3);
$Virtualservices_3 = str_replace('e', 'ⓔ', $Virtualservices_3);
$Virtualservices_3 = str_replace('f', 'ⓕ', $Virtualservices_3);
$Virtualservices_3 = str_replace('g', 'ⓖ', $Virtualservices_3);
$Virtualservices_3 = str_replace('h', 'ⓗ', $Virtualservices_3);
$Virtualservices_3 = str_replace('i', 'ⓘ', $Virtualservices_3);
$Virtualservices_3 = str_replace('j', 'ⓙ', $Virtualservices_3);
$Virtualservices_3 = str_replace('k', 'ⓚ', $Virtualservices_3);
$Virtualservices_3 = str_replace('l', 'ⓛ', $Virtualservices_3);
$Virtualservices_3 = str_replace('m', 'ⓜ', $Virtualservices_3);
$Virtualservices_3 = str_replace('n', 'ⓝ', $Virtualservices_3);
$Virtualservices_3 = str_replace('o', 'ⓞ', $Virtualservices_3);
$Virtualservices_3 = str_replace('p', 'ⓟ', $Virtualservices_3);
$Virtualservices_3 = str_replace('q', 'ⓠ', $Virtualservices_3);
$Virtualservices_3 = str_replace('r', 'ⓡ', $Virtualservices_3);
$Virtualservices_3 = str_replace('s', 'ⓢ', $Virtualservices_3);
$Virtualservices_3 = str_replace('t', 'ⓣ', $Virtualservices_3);
$Virtualservices_3 = str_replace('u', 'ⓤ', $Virtualservices_3);
$Virtualservices_3 = str_replace('v', 'ⓥ', $Virtualservices_3);
$Virtualservices_3 = str_replace('w', 'ⓦ', $Virtualservices_3);
$Virtualservices_3 = str_replace('x', 'ⓧ', $Virtualservices_3);
$Virtualservices_3 = str_replace('y', 'ⓨ', $Virtualservices_3);
$Virtualservices_3 = str_replace('z', 'ⓩ', $Virtualservices_3);

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$Virtualservices_3."".$smile
   ]);
}

if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $items = ['، 🍕💕#','❥⁽🍿₎ٰ⇣ᴗ̈
','.⏳🧡:)','،🗞❤️#!','،🗞❤️#!
','، 🌼🖇"⌗
','««🍟🌿','،🌼🖤) ء','،🥀💛) ء','،📆🌼) ء','(⏰💛ء','،"(🥀💔"ء','،"(✨✊🏽"ء','،♥️🌿) ء','،"(💛🔐 ء','!،🙂💔 ء','،💤🌿،!','،🔐🌸)','،🕸💛،','،!👀💚،','،💆🏼💛) ء
','!🥀🎼 ، ⇣','!🥀🎼 ، ⇣','،!👅🌸) ء','،! 🚜💕 ⇣','،"(🔐💜 ء','،"(🔐💜 ء','⇡ ،💗🎧 ٰء
',];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);
   $Virtualservices_3 = $text;
$Virtualservices_3 = str_replace('a','⎛α⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('b','⎛в⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('c','⎛c⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('d','⎛ɒ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('e','⎛є⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('f','⎛f⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('g','⎛ɢ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('h','⎛н⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('i','⎛ɪ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('j','⎛ᴊ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('s','⎛ĸ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('l','⎛ℓ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('m','⎛м⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('n','⎛и⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('o','⎛σ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('p','⎛ρ⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('q','⎛q⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('r','⎛я⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('f','⎛s⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('t','⎛τ⎞ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('u','⎛υ⎞ ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('v','⎛v⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('w','⎛ω⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('x','⎛x⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('y','⎛y⎞',$Virtualservices_3); 
$Virtualservices_3 = str_replace('z','⎛z⎞',$Virtualservices_3); 
 /*
🌟‌ اوپن شده در چنل های
💚 @Virtualservices_3
💚 @LrixeNumber
💚 @Jordan_Source

➖ نوشته شده توسط: @HOKOMAT_ARAB
منبع بپاکی یعنی ریدی رو کفن زنده و مرده مادرت 😑
*/

$Virtualservices_3 = str_replace('ض','ضِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ص','صِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ث','ثِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ق','قِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ف','فِٰ͒ـِﮧۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('غ','غِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ع','عِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ه','ۿۿہ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('خ','خِٰ̐ـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ح','حِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ج','جِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ش','شِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('س','سِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ي','يِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ب','بِٰـِﮧۢ',$Virtualservices_3);
$Virtualservices_3 = str_replace('ل','لِٰـِﮧۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ا','آ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ت','تِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ن','نِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('م','مِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ك','ڪِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ة','ةً',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ء','ء',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ظ','ظِٰـﮧِۢ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ط','طِٰـﮧِۢ',$Virtualservices_3); 
 $Virtualservices_3 = str_replace('ذ','ذٰ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('د','د',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ز','ژ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('ر','رٰ',$Virtualservices_3); 
$Virtualservices_3 = str_replace('و','ﯛ̲୭',$Virtualservices_3); 
 $Virtualservices_3 = str_replace('ى','ىٍ',$Virtualservices_3);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$Virtualservices_3."".$smile
   ]);
}

if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); // @HOKOMAT_ARAB | @HOKOMAT_ARAB //
$LrixeNumber = str_replace('a','ᗩ',$text);
$LrixeNumber = str_replace("b","ᗷ",$LrixeNumber);
$LrixeNumber = str_replace("c","ᑕ",$LrixeNumber);
$LrixeNumber = str_replace("d","ᗪ",$LrixeNumber);
$LrixeNumber = str_replace("e","E",$LrixeNumber);
$LrixeNumber = str_replace("E","E",$LrixeNumber);
$LrixeNumber = str_replace("g","G",$LrixeNumber);
$LrixeNumber = str_replace("h","ᕼ",$LrixeNumber);
$LrixeNumber = str_replace("i","I",$LrixeNumber);
$LrixeNumber = str_replace("j","ᒍ",$LrixeNumber);
$LrixeNumber = str_replace("k","K",$LrixeNumber);
$LrixeNumber = str_replace("l","ᒪ",$LrixeNumber);
$LrixeNumber = str_replace("m","ᗰ",$LrixeNumber);
$LrixeNumber = str_replace("n","ᑎ",$LrixeNumber);
$LrixeNumber = str_replace("o","O",$LrixeNumber);
$LrixeNumber = str_replace("p","ᑭ",$LrixeNumber);
$LrixeNumber = str_replace("q","ᑫ",$LrixeNumber);
$LrixeNumber = str_replace("r","ᖇ",$LrixeNumber);
$LrixeNumber = str_replace("s","ᔕ",$LrixeNumber);
$LrixeNumber = str_replace("t","T",$LrixeNumber);
$LrixeNumber = str_replace("u","ᑌ",$LrixeNumber);
$LrixeNumber = str_replace("v","ᐯ",$LrixeNumber);
$LrixeNumber = str_replace("w","ᗯ",$LrixeNumber);
$LrixeNumber = str_replace("x","᙭",$LrixeNumber);
$LrixeNumber = str_replace("y","Y",$LrixeNumber);
$LrixeNumber = str_replace("z","ᘔ",$LrixeNumber);

$LrixeNumber = str_replace('ض','᎗ᘞ̇',$LrixeNumber); 
$LrixeNumber = str_replace('ص','᎗ᘗ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','᎗̇̈ɹ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','ᓆ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','ᓅ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','᎗ჺ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','᎗ϛ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','᎗බ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','ᓘ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','ᓗ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','ᓗฺ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','᎗ɹ̇̈ɹɹ',$LrixeNumber); 
$LrixeNumber = str_replace('س','᎗ɹɹɹ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','᎗̤ɹ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','᎗̣ɹ',$LrixeNumber);
$LrixeNumber = str_replace('ل','⅃',$LrixeNumber); 
$LrixeNumber = str_replace('ا','Ȋ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','᎗̈ɹ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','᎗̇ɹ',$LrixeNumber); 
$LrixeNumber = str_replace('ܭ','ك',$LrixeNumber); 
$LrixeNumber = str_replace('م','ᓄ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','᎗Ꭷ',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','᎗̇Ь',$LrixeNumber); 
$LrixeNumber = str_replace('ط','᎗Ь',$LrixeNumber); 
 $LrixeNumber = str_replace('ذ','̇ↄ',$LrixeNumber); 
$LrixeNumber = str_replace('د','ↄ',$LrixeNumber); 
$LrixeNumber = str_replace('ز','j',$LrixeNumber); 
$LrixeNumber = str_replace('ر','ȷ',$LrixeNumber); 
$LrixeNumber = str_replace('و','g',$LrixeNumber); 
 $LrixeNumber = str_replace('ى','ʟɾʅ',$LrixeNumber);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$LrixeNumber."".$meme
]);}

if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); // @HOKOMAT_ARAB | @HOKOMAT_ARAB //
$LrixeNumber = str_replace('a','Ꭿ',$text);
$LrixeNumber = str_replace("b","Ᏸ",$LrixeNumber);
$LrixeNumber = str_replace("c","Ꮸ",$LrixeNumber);
$LrixeNumber = str_replace("d","Ꮷ",$LrixeNumber);
$LrixeNumber = str_replace("e","Ꮛ",$LrixeNumber);
$LrixeNumber = str_replace("f","Ꭶ",$LrixeNumber);
$LrixeNumber = str_replace("g","Ᏻ",$LrixeNumber);
$LrixeNumber = str_replace("h","Ᏺ",$LrixeNumber);
$LrixeNumber = str_replace("i","Ꭸ",$LrixeNumber);
$LrixeNumber = str_replace("j","Ꮰ",$LrixeNumber);
$LrixeNumber = str_replace("k","Ꮵ",$LrixeNumber);
$LrixeNumber = str_replace("l","Ꮭ",$LrixeNumber);
$LrixeNumber = str_replace("m","ᗰ",$LrixeNumber);
$LrixeNumber = str_replace("n","Ꮑ",$LrixeNumber);
$LrixeNumber = str_replace("o","Ꭷ",$LrixeNumber);
$LrixeNumber = str_replace("p","Ꭾ",$LrixeNumber);
$LrixeNumber = str_replace("q","Ꮕ",$LrixeNumber);
$LrixeNumber = str_replace("r","ᖇ",$LrixeNumber);
$LrixeNumber = str_replace("s","Ꮥ",$LrixeNumber);
$LrixeNumber = str_replace("t","Ꮱ",$LrixeNumber);
$LrixeNumber = str_replace("u","Ꮼ",$LrixeNumber);
$LrixeNumber = str_replace("v","Ꮙ",$LrixeNumber);
$LrixeNumber = str_replace("w","Ꮗ",$LrixeNumber);
$LrixeNumber = str_replace("x","Ꮂ",$LrixeNumber);
$LrixeNumber = str_replace("y","Ꮍ",$LrixeNumber);
$LrixeNumber = str_replace("z","ᔓ",$LrixeNumber);
                     
$LrixeNumber = str_replace('ض','ضٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ص','صٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ث','ثٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ق','قٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ف','فٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('غ','غٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ع','عٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ه','هٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('خ','خٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ح','حٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ج','جٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ش','شٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('س','سٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ي','يٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ب','بٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ل','لہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ا','اٰ',$LrixeNumber);
$LrixeNumber = str_replace('ت','تٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ن','نٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('م','مٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ك','كٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber);
$LrixeNumber = str_replace('ء','ء',$LrixeNumber);
$LrixeNumber = str_replace('ظ','ظٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ط','طٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ذ','ذٖ',$LrixeNumber);
$LrixeNumber = str_replace('د','دٰ',$LrixeNumber);
$LrixeNumber = str_replace('ز','زٖ',$LrixeNumber);
$LrixeNumber = str_replace('ر','رٰ',$LrixeNumber);
$LrixeNumber = str_replace('و','وٰ',$LrixeNumber);
$LrixeNumber = str_replace('ى','ى',$LrixeNumber);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$LrixeNumber."".$meme
]);}
// L ordt ab adol | L ordt ab adol //
if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a',"ᵃ",$text);
$LrixeNumber = str_replace("b","ᵇ",$LrixeNumber);
$LrixeNumber = str_replace("c","ᶜ",$LrixeNumber);
$LrixeNumber = str_replace("d","ᵈ",$LrixeNumber);
$LrixeNumber = str_replace("e","ᵉ",$LrixeNumber);
$LrixeNumber = str_replace("f","ᶠ",$LrixeNumber);
$LrixeNumber = str_replace("g","ᵍ",$LrixeNumber);
$LrixeNumber = str_replace("h","ʰ",$LrixeNumber);
$LrixeNumber = str_replace("i","ᶤ",$LrixeNumber);
$LrixeNumber = str_replace("j","ʲ",$LrixeNumber);
$LrixeNumber = str_replace("k","ᵏ",$LrixeNumber);
$LrixeNumber = str_replace("l","ˡ",$LrixeNumber);
$LrixeNumber = str_replace("m","ᵐ",$LrixeNumber);
$LrixeNumber = str_replace("n","ᶰ",$LrixeNumber);
$LrixeNumber = str_replace("o","ᵒ",$LrixeNumber);
$LrixeNumber = str_replace("p","ᵖ",$LrixeNumber);
$LrixeNumber = str_replace("q","ᵠ",$LrixeNumber);
$LrixeNumber = str_replace("r","ʳ",$LrixeNumber);
$LrixeNumber = str_replace("s","ˢ",$LrixeNumber);
$LrixeNumber = str_replace("t","ᵗ",$LrixeNumber);
$LrixeNumber = str_replace("u","ᵘ",$LrixeNumber);
$LrixeNumber = str_replace("v","ᵛ",$LrixeNumber);
$LrixeNumber = str_replace("w","ʷ",$LrixeNumber);
$LrixeNumber = str_replace("x","ˣ",$LrixeNumber);
$LrixeNumber = str_replace("y","ʸ",$LrixeNumber);
$LrixeNumber = str_replace("z","ᶻ",$LrixeNumber);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$LrixeNumber."".$meme
]);}
/*
🌟‌ اوپن شده در چنل های
💚 @Virtualservices_3
💚 @LrixeNumber
💚 @Jordan_Source

➖ نوشته شده توسط: @HOKOMAT_ARAB
منبع بپاکی یعنی ریدی رو کفن زنده و مرده مادرت 😑
*/

if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','Ａ',$text);
$LrixeNumber = str_replace("b","Ｂ",$LrixeNumber);
$LrixeNumber = str_replace("c","Ｃ",$LrixeNumber);
$LrixeNumber = str_replace("d","Ｄ",$LrixeNumber);
$LrixeNumber = str_replace("e","Ｅ",$LrixeNumber);
$LrixeNumber = str_replace("E","Ｆ",$LrixeNumber);
$LrixeNumber = str_replace("g","Ｇ",$LrixeNumber);
$LrixeNumber = str_replace("h","Ｈ",$LrixeNumber);
$LrixeNumber = str_replace("i","Ｉ",$LrixeNumber);
$LrixeNumber = str_replace("j","Ｊ",$LrixeNumber);
$LrixeNumber = str_replace("k","Ｋ",$LrixeNumber);
$LrixeNumber = str_replace("l","Ｌ",$LrixeNumber);
$LrixeNumber = str_replace("m","Ｍ",$LrixeNumber);
$LrixeNumber = str_replace("n","Ｎ",$LrixeNumber);
$LrixeNumber = str_replace("o","Ｏ",$LrixeNumber);
$LrixeNumber = str_replace("p","Ｐ",$LrixeNumber);
$LrixeNumber = str_replace("q","Ｑ",$LrixeNumber);
$LrixeNumber = str_replace("r","Ｒ",$LrixeNumber);
$LrixeNumber = str_replace("s","Ｓ",$LrixeNumber);
$LrixeNumber = str_replace("t","Ｔ",$LrixeNumber);
$LrixeNumber = str_replace("u","U",$LrixeNumber);
$LrixeNumber = str_replace("v","Ｖ",$LrixeNumber);
$LrixeNumber = str_replace("w","Ｗ",$LrixeNumber);
$LrixeNumber = str_replace("x","Ｘ",$LrixeNumber);
$LrixeNumber = str_replace("y","Ｙ",$LrixeNumber);
$LrixeNumber = str_replace("z","Ｚ",$LrixeNumber);
// @HOKOMAT_ARAB | @HOKOMAT_ARAB //
$LrixeNumber = str_replace('ع','عٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ض','ضٰہٰٖ ',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ثٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','فٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','غٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','هٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','حٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','جٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','شٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','بٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','يٰہٰٖ',$LrixeNumber);
$LrixeNumber = str_replace('ل','لہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ا','اٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','تٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','كٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ءِ',$LrixeNumber); 
$LrixeNumber = str_replace('ذ','ذٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ط','طٰہٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('د','دٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ز','زٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ر','رٰ',$LrixeNumber); 
$LrixeNumber = str_replace('و','وَٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ى','ىٰ',$LrixeNumber); 
 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$LrixeNumber."".$meme
]);}

if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','𝗔',$text); 
$LrixeNumber = str_replace("b","𝗕",$LrixeNumber); 
$LrixeNumber = str_replace("c","𝗖",$LrixeNumber); 
$LrixeNumber = str_replace("d","𝗗",$LrixeNumber); 
$LrixeNumber = str_replace("e","𝗘",$LrixeNumber); 
$LrixeNumber = str_replace("f","𝗙",$LrixeNumber); 
$LrixeNumber = str_replace("g","𝗚",$LrixeNumber); 
$LrixeNumber = str_replace("h","𝗛",$LrixeNumber); 
$LrixeNumber = str_replace("i","𝗜",$LrixeNumber); 
$LrixeNumber = str_replace("j","𝗝",$LrixeNumber); 
$LrixeNumber = str_replace("k","𝗞",$LrixeNumber); 
$LrixeNumber = str_replace("l","𝗟",$LrixeNumber); 
$LrixeNumber = str_replace("m","𝗠",$LrixeNumber); 
$LrixeNumber = str_replace("n","𝗡",$LrixeNumber); 
$LrixeNumber = str_replace("o","𝗢",$LrixeNumber); 
$LrixeNumber = str_replace("p","𝗣",$LrixeNumber); 
$LrixeNumber = str_replace("q","𝗤",$LrixeNumber); 
$LrixeNumber = str_replace("r","𝗥",$LrixeNumber); 
$LrixeNumber = str_replace("s","𝗦",$LrixeNumber); 
$LrixeNumber = str_replace("t","𝗧",$LrixeNumber); 
$LrixeNumber = str_replace("u","𝗨",$LrixeNumber); 
$LrixeNumber = str_replace("v","𝗩",$LrixeNumber); 
$LrixeNumber = str_replace("w","𝗪",$LrixeNumber); 
$LrixeNumber = str_replace("x","𝗫",$LrixeNumber); 
$LrixeNumber = str_replace("y","𝗬",$LrixeNumber); 
$LrixeNumber = str_replace("z","𝗭",$LrixeNumber); 
                    // @HOKOMAT_ARAB | @HOKOMAT_ARAB //
$LrixeNumber = str_replace('ض','ضـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ثـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','فـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','غـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','عـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','هـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','حـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','جـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','شـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','يـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','بـٰ̲ـہ',$LrixeNumber);
$LrixeNumber = str_replace('ل','لـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ا','اٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','تـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','كـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ط','طـٰ̲ـہ',$LrixeNumber); 
$LrixeNumber = str_replace('ذ','ذٰ',$LrixeNumber); 
$LrixeNumber = str_replace('د','دٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ز','زٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ر','رٰ',$LrixeNumber); 
$LrixeNumber = str_replace('و','وٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ى','ىَ',$LrixeNumber); 

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$LrixeNumber."".$meme
]);}


if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','⧼α⧽',$text); 
$LrixeNumber = str_replace('b','⧼в⧽',$LrixeNumber); 
$LrixeNumber = str_replace('c','⧼c⧽',$LrixeNumber); 
$LrixeNumber = str_replace('d','⧼ɒ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('e','⧼є⧽',$LrixeNumber); 
$LrixeNumber = str_replace('f','⧼f⧽',$LrixeNumber); 
$LrixeNumber = str_replace('g','⧼ɢ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('h','⧼н⧽',$LrixeNumber); 
$LrixeNumber = str_replace('i','⧼ɪ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('j','⧼ᴊ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('k','⧼ĸ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('l','⧼ℓ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('m','⧼м⧽',$LrixeNumber); 
$LrixeNumber = str_replace('n','⧼и⧽',$LrixeNumber); 
$LrixeNumber = str_replace('o','⧼σ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('p','⧼ρ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('q','⧼q⧽',$LrixeNumber); 
$LrixeNumber = str_replace('r','⧼я⧽',$LrixeNumber); 
$LrixeNumber = str_replace('s','⧼s⧽',$LrixeNumber); 
$LrixeNumber = str_replace('t','⧼τ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('u','⧼υ⧽',$LrixeNumber); 
$LrixeNumber = str_replace('v','⧼v⧽',$LrixeNumber); 
$LrixeNumber = str_replace('w','⧼ω⧽',$LrixeNumber); 
$LrixeNumber = str_replace('x','⧼x⧽',$LrixeNumber); 
$LrixeNumber = str_replace('y','⧼y⧽',$LrixeNumber); 
$LrixeNumber = str_replace('z','⧼z⧽',$LrixeNumber); 
// DevOscar | DevOscar //
$LrixeNumber = str_replace('ض','ضـٰ๋۪͜ﮧٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صـٌٍ๋ۤ͜ﮧْ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ث̲ꫭـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قٰٰྀ̲ـِٰ̲ﮧْ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','',$LrixeNumber); 
$LrixeNumber = str_replace('غ','فـٌٍ๋ۤ͜ﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','غـّٰ̐ہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','ٰ̲ھہ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خ̲ﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','ح̲ꪳـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','ج̲ꪸـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','ش̲ꪾـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سـ̷ٰٰﮧْ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','يـِٰ̲ﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','ب̲ꪰـﮧ',$LrixeNumber);
$LrixeNumber = str_replace('ل','لٍُـّٰ̐ہ',$LrixeNumber); 
$LrixeNumber = str_replace('ا',' ཻا ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','تـٰۧﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نٰ̲̐ـﮧْ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مٰٰྀ̲ـِٰ̲ﮧْ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','كـِّﮧْٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظَـ๋͜ﮧْ',$LrixeNumber); 
$LrixeNumber = str_replace('ط','ط̲꫁ـﮧ',$LrixeNumber); 
 $LrixeNumber = str_replace('ذ','ذٖ',$LrixeNumber); 
$LrixeNumber = str_replace('د','دُ',$LrixeNumber); 
$LrixeNumber = str_replace('ز','ژٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ر','',$LrixeNumber); 
$LrixeNumber = str_replace('و','ﯛ૭',$LrixeNumber); 
 $LrixeNumber = str_replace('ى','ىِ',$LrixeNumber); 
/*
🌟‌ اوپن شده در چنل های
💚 @Virtualservices_3
💚 @LrixeNumber
💚 @Jordan_Source

➖ نوشته شده توسط: @HOKOMAT_ARAB
منبع بپاکی یعنی ریدی رو کفن زنده و مرده مادرت 😑
*/

bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$LrixeNumber."".$meme
]);}


if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','🅰',$text); 
$LrixeNumber = str_replace('b','🅱',$LrixeNumber); 
$LrixeNumber = str_replace('c','🅲',$LrixeNumber); 
$LrixeNumber = str_replace('d','🅳',$LrixeNumber); 
$LrixeNumber = str_replace('e','🅴',$LrixeNumber); 
$LrixeNumber = str_replace('f','🅵',$LrixeNumber); 
$LrixeNumber = str_replace('g','🅶',$LrixeNumber); 
$LrixeNumber = str_replace('h','🅷',$LrixeNumber); 
$LrixeNumber = str_replace('i','🅸',$LrixeNumber); 
$LrixeNumber = str_replace('j','🅹',$LrixeNumber); 
$LrixeNumber = str_replace('k','🅺',$LrixeNumber); 
$LrixeNumber = str_replace('l','🅻',$LrixeNumber); 
$LrixeNumber = str_replace('m','🅼',$LrixeNumber); 
$LrixeNumber = str_replace('n','🅽',$LrixeNumber); 
$LrixeNumber = str_replace('o','🅾',$LrixeNumber); 
$LrixeNumber = str_replace('p','🅿',$LrixeNumber); 
$LrixeNumber = str_replace('q','🆀',$LrixeNumber); 
$LrixeNumber = str_replace('r','🆁',$LrixeNumber); 
$LrixeNumber = str_replace('s','🆂',$LrixeNumber); 
$LrixeNumber = str_replace('t','🆃',$LrixeNumber); 
$LrixeNumber = str_replace('u',' 🆄',$LrixeNumber); 
$LrixeNumber = str_replace('v','🆅',$LrixeNumber); 
$LrixeNumber = str_replace('w','🆆',$LrixeNumber); 
$LrixeNumber = str_replace('x','🆇',$LrixeNumber); 
$LrixeNumber = str_replace('y','🆈',$LrixeNumber); 
$LrixeNumber = str_replace('z','🆉',$LrixeNumber); 
// Lo r dtab ad ol | L o rdtab ad ol //
$LrixeNumber = str_replace('ض','ضـ๋͜‏ـﮧ ',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ثـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','ف͒ـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','غـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','عـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','ۿۿہ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خ̐ـ๋͜‏ـﮧ ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','حـ๋͜‏ـﮧ ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','جـ๋͜‏ـﮧ ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','شـ๋͜‏ـﮧ ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ي',' يـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','  بـ๋͜‏ـﮧ',$LrixeNumber);
$LrixeNumber = str_replace('ل',' لـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ا','آ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','  تـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','ڪـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظـ๋͜‏ـﮧ',$LrixeNumber); 
$LrixeNumber = str_replace('ط','طـ๋͜‏ـﮧ',$LrixeNumber); 
 $LrixeNumber = str_replace('ذ','ذِ',$LrixeNumber); 
$LrixeNumber = str_replace('د','دٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ز','زً',$LrixeNumber); 
$LrixeNumber = str_replace('ر','ر',$LrixeNumber); 
$LrixeNumber = str_replace('و','ﯛ̲୭',$LrixeNumber); 
 $LrixeNumber = str_replace('ى','ىٰ',$LrixeNumber);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$LrixeNumber."".$meme
]);}
// @HOKOMAT_ARAB | @HOKOMAT_ARAB //
if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','⎛α⎞',$text); 
$LrixeNumber = str_replace('b','⎛в⎞',$LrixeNumber); 
$LrixeNumber = str_replace('c','⎛c⎞',$LrixeNumber); 
$LrixeNumber = str_replace('d','⎛ɒ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('e','⎛є⎞',$LrixeNumber); 
$LrixeNumber = str_replace('f','⎛f⎞',$LrixeNumber); 
$LrixeNumber = str_replace('g','⎛ɢ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('h','⎛н⎞',$LrixeNumber); 
$LrixeNumber = str_replace('i','⎛ɪ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('j','⎛ᴊ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('k','⎛ĸ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('l','⎛ℓ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('m','⎛м⎞',$LrixeNumber); 
$LrixeNumber = str_replace('n','⎛и⎞',$LrixeNumber); 
$LrixeNumber = str_replace('o','⎛σ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('p','⎛ρ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('q','⎛q⎞',$LrixeNumber); 
$LrixeNumber = str_replace('r','⎛я⎞',$LrixeNumber); 
$LrixeNumber = str_replace('s','⎛s⎞',$LrixeNumber); 
$LrixeNumber = str_replace('t','⎛τ⎞ ',$LrixeNumber); 
$LrixeNumber = str_replace('u','⎛υ⎞ ',$LrixeNumber); 
$LrixeNumber = str_replace('v','⎛v⎞',$LrixeNumber); 
$LrixeNumber = str_replace('w','⎛ω⎞',$LrixeNumber); 
$LrixeNumber = str_replace('x','⎛x⎞',$LrixeNumber); 
$LrixeNumber = str_replace('y','⎛y⎞',$LrixeNumber); 
$LrixeNumber = str_replace('z','⎛z⎞',$LrixeNumber); 
 
$LrixeNumber = str_replace('ض','ضِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ثِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','فِٰ͒ـِﮧۢ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','غِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','عِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','ۿۿہ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خِٰ̐ـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','حِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','جِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','شِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','يِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','بِٰـِﮧۢ',$LrixeNumber);
$LrixeNumber = str_replace('ل','لِٰـِﮧۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ا','آ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','تِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','ڪِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ط','طِٰـﮧِۢ',$LrixeNumber); 
 $LrixeNumber = str_replace('ذ','ذٰ',$LrixeNumber); 
$LrixeNumber = str_replace('د','د',$LrixeNumber); 
$LrixeNumber = str_replace('ز','ژ',$LrixeNumber); 
$LrixeNumber = str_replace('ر','رٰ',$LrixeNumber); 
$LrixeNumber = str_replace('و','ﯛ̲୭',$LrixeNumber); 
 $LrixeNumber = str_replace('ى','ىٍ',$LrixeNumber);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$LrixeNumber."".$meme
]);}


if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','̶a̶',$text); 
$LrixeNumber = str_replace('b','b̶',$LrixeNumber); 
$LrixeNumber = str_replace('c','c̶',$LrixeNumber); 
$LrixeNumber = str_replace('d','d̶',$LrixeNumber); 
$LrixeNumber = str_replace('e','e̶',$LrixeNumber); 
$LrixeNumber = str_replace('f','f̶',$LrixeNumber); 
$LrixeNumber = str_replace('g','g̶',$LrixeNumber); 
$LrixeNumber = str_replace('h','h̶',$LrixeNumber); 
$LrixeNumber = str_replace('i','i̶',$LrixeNumber); 
$LrixeNumber = str_replace('j','j̶',$LrixeNumber); 
$LrixeNumber = str_replace('k','k̶',$LrixeNumber); 
$LrixeNumber = str_replace('l','l̶',$LrixeNumber); 
$LrixeNumber = str_replace('m','m̶',$LrixeNumber); 
$LrixeNumber = str_replace('n','n̶',$LrixeNumber); 
$LrixeNumber = str_replace('o','o̶',$LrixeNumber); 
$LrixeNumber = str_replace('p','p̶',$LrixeNumber); 
$LrixeNumber = str_replace('q','q̶',$LrixeNumber); 
$LrixeNumber = str_replace('r','r̶',$LrixeNumber); 
$LrixeNumber = str_replace('s','s̶',$LrixeNumber); 
$LrixeNumber = str_replace('t','t̶',$LrixeNumber); 
$LrixeNumber = str_replace('u','ᵘ̶ ',$LrixeNumber); 
$LrixeNumber = str_replace('v','v̶',$LrixeNumber); 
$LrixeNumber = str_replace('w','w̶',$LrixeNumber); 
$LrixeNumber = str_replace('x','x̶',$LrixeNumber); 
$LrixeNumber = str_replace('y','y̶',$LrixeNumber); 
$LrixeNumber = str_replace('z','z̶',$LrixeNumber); 
// @HOKOMAT_ARAB | @HOKOMAT_ARAB //
 $LrixeNumber = str_replace('ض','ضۜہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صۛہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ثہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قྀ̲ہٰٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','ف͒ہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','غہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','ۤ؏ـ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','ھہ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خٰ̐ہ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','حہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','جْۧ ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','شِٰہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سٰٰٓ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','يِٰہ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','بّہ',$LrixeNumber);
$LrixeNumber = str_replace('ل','ل',$LrixeNumber); 
$LrixeNumber = str_replace('ا','آ',$LrixeNumber); 
$LrixeNumber = str_replace('ت',' تَہَٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نَِٰہ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','ڪٰྀہٰٰٖ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مـ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظۗـہٰٰ',$LrixeNumber); 
$LrixeNumber = str_replace('ط','طۨہٰٰ',$LrixeNumber); 
 $LrixeNumber = str_replace('ذ','ذِ',$LrixeNumber); 
$LrixeNumber = str_replace('د','دُ',$LrixeNumber); 
$LrixeNumber = str_replace('ز','ژ',$LrixeNumber); 
$LrixeNumber = str_replace('ر','رٰ',$LrixeNumber); 
$LrixeNumber = str_replace('و','وً',$LrixeNumber); 
 $LrixeNumber = str_replace('ى','ى',$LrixeNumber);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$LrixeNumber."".$meme
]);}
/*
🌟‌ اوپن شده در چنل های
💚 @Virtualservices_3
💚 @LrixeNumber
💚 @Jordan_Source

➖ نوشته شده توسط: @HOKOMAT_ARAB
منبع بپاکی یعنی ریدی رو کفن زنده و مرده مادرت 😑
*/

if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼🌿﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','🅐',$text); 
$LrixeNumber = str_replace("b","🅑",$LrixeNumber); 
$LrixeNumber = str_replace("c","🅒",$LrixeNumber); 
$LrixeNumber = str_replace("d","🅓",$LrixeNumber); 
$LrixeNumber = str_replace("e","🅔",$LrixeNumber); 
$LrixeNumber = str_replace("f","🅕",$LrixeNumber); 
$LrixeNumber = str_replace("g","🅖",$LrixeNumber); 
$LrixeNumber = str_replace("h","🅗",$LrixeNumber); 
$LrixeNumber = str_replace("i","🅘",$LrixeNumber); 
$LrixeNumber = str_replace("j","🅙",$LrixeNumber); 
$LrixeNumber = str_replace("k","🅚",$LrixeNumber); 
$LrixeNumber = str_replace("l","🅛",$LrixeNumber); 
$LrixeNumber = str_replace("m","🅜",$LrixeNumber); 
$LrixeNumber = str_replace("n","🅝",$LrixeNumber); 
$LrixeNumber = str_replace("o","🅞",$LrixeNumber); 
$LrixeNumber = str_replace("p","🅟",$LrixeNumber); 
$LrixeNumber = str_replace("q","🅠",$LrixeNumber); 
$LrixeNumber = str_replace("r","🅡",$LrixeNumber); 
$LrixeNumber = str_replace("s","🅢",$LrixeNumber); 
$LrixeNumber = str_replace("t","🅣",$LrixeNumber); 
$LrixeNumber = str_replace("u"," 🅤",$LrixeNumber); 
$LrixeNumber = str_replace("v","🅥",$LrixeNumber); 
$LrixeNumber = str_replace("w","🅦",$LrixeNumber); 
$LrixeNumber = str_replace("x","🅧",$LrixeNumber); 
$LrixeNumber = str_replace("y","🅨",$LrixeNumber); 
$LrixeNumber = str_replace("z","🅩",$LrixeNumber); 
 
$LrixeNumber = str_replace('ض','ضً',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صً',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ثہ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قہً',$LrixeNumber); 
$LrixeNumber = str_replace('ف','فُہ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','غہ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','عہُ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','ه',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خہ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','حہ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','جہ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','شہ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سہ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','يہ',$LrixeNumber); 
$LrixeNumber = str_replace('ب',' ٻً',$LrixeNumber);
$LrixeNumber = str_replace('ل','لہ',$LrixeNumber); 
$LrixeNumber = str_replace('ا',' ٳ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','تہ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نٍ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','كُہ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مْ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظً',$LrixeNumber); 
$LrixeNumber = str_replace('ط','طہ',$LrixeNumber); 
 $LrixeNumber = str_replace('ذ','ذً',$LrixeNumber); 
$LrixeNumber = str_replace('د','دِ',$LrixeNumber); 
$LrixeNumber = str_replace('ز','زً',$LrixeNumber); 
$LrixeNumber = str_replace('ر','ڒٍ',$LrixeNumber); 
$LrixeNumber = str_replace('و','وٌ',$LrixeNumber); 
 $LrixeNumber = str_replace('ى','ىّ',$LrixeNumber);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$LrixeNumber."".$meme
]);}
if($text != '/start' and $text !='/panel'   and  file_get_contents("DevOscar/$user_id/zeakef.txt") =='LrixeNumber0'){
// @Lor dtaba dol | @Lor dtabadol //
  $ss = [' •🌱💚﴿ֆ ❥', '🍿﴿ֆ ❥', '• 🌸💸 ❥˓  ', '🖤🌞﴿ֆ', ' • 🐼??﴾ֆ', ' •🙊💙﴿ֆ ❥', '-💁🏼‍♂️✨﴿ֆ ❥ ', '•|• 〄💖‘',
                        ' ⚡️🌞 •|•℡', '- ⁽🙆‍♂️✨₎ֆ', '❥┇💁🏼‍♂️🔥“', '💜💭℡ֆ', '-┆💙🙋🏼‍♂️♕', '- ⁽🙆🏻🍿₎ֆ',
                        '“̯ 🐼💗 |℡', '⁞ 🐝🍷', '┋⁽❥̚͢₎ 🐣💗', '•|• ✨🌸‘', '  ֆ 💭💔ۦ', 'ֆ 💛💭ۦ', 'ֆ ⚡️🔱ۦ',
                        '℡ᴖ̈💜✨⋮', '⋮⁽🌔☄️₎ۦ˛', '⁞❉💥┋♩', ' ⁞✦⁽☻🔥₎“ٰۦ', '℡ ̇₎ ✨🐯⇣✦', '⁞♩⁽🌞🌩₎⇣✿',
                        'ۦٰ‏┋❥ ͢˓🦁💛ۦ‏', '⚡️♛ֆ₎', '♛⇣🐰☄️₎✦', '⁾⇣✿💖┊❥', ' ₎✿💥😈 ⁞“❥', '😴🌸✿⇣', '❥┊⁽ ℡🦁🌸'];
  $zz = array_rand($ss,1);
  $meme = $ss[$zz];
   $count = count($text); 
$LrixeNumber = str_replace('a','⎛α⎞',$text); 
$LrixeNumber = str_replace('b','⎛в⎞',$LrixeNumber); 
$LrixeNumber = str_replace('c','⎛c⎞',$LrixeNumber); 
$LrixeNumber = str_replace('d','⎛ɒ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('e','⎛є⎞',$LrixeNumber); 
$LrixeNumber = str_replace('f','⎛f⎞',$LrixeNumber); 
$LrixeNumber = str_replace('g','⎛ɢ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('h','⎛н⎞',$LrixeNumber); 
$LrixeNumber = str_replace('i','⎛ɪ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('j','⎛ᴊ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('k','⎛ĸ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('l','⎛ℓ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('m','⎛м⎞',$LrixeNumber); 
$LrixeNumber = str_replace('n','⎛и⎞',$LrixeNumber); 
$LrixeNumber = str_replace('o','⎛σ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('p','⎛ρ⎞',$LrixeNumber); 
$LrixeNumber = str_replace('q','⎛q⎞',$LrixeNumber); 
$LrixeNumber = str_replace('r','⎛я⎞',$LrixeNumber); 
$LrixeNumber = str_replace('s','⎛s⎞',$LrixeNumber); 
$LrixeNumber = str_replace('t','⎛τ⎞ ',$LrixeNumber); 
$LrixeNumber = str_replace('u','⎛υ⎞ ',$LrixeNumber); 
$LrixeNumber = str_replace('v','⎛v⎞',$LrixeNumber); 
$LrixeNumber = str_replace('w','⎛ω⎞',$LrixeNumber); 
$LrixeNumber = str_replace('x','⎛x⎞',$LrixeNumber); 
$LrixeNumber = str_replace('y','⎛y⎞',$LrixeNumber); 
$LrixeNumber = str_replace('z','⎛z⎞',$LrixeNumber); 
$LrixeNumber = str_replace('ض','ضِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ص','صِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ث','ثِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ق','قِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ف','فِٰ͒ـِﮧۢ',$LrixeNumber); 
$LrixeNumber = str_replace('غ','غِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ع','عِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ه','ۿۿہ',$LrixeNumber); 
$LrixeNumber = str_replace('خ','خِٰ̐ـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ح','حِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ج','جِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ش','شِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('س','سِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ي','يِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ب','بِٰـِﮧۢ',$LrixeNumber);
$LrixeNumber = str_replace('ل','لِٰـِﮧۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ا','آ',$LrixeNumber); 
$LrixeNumber = str_replace('ت','تِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ن','نِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('م','مِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ك','ڪِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ة','ةً',$LrixeNumber); 
$LrixeNumber = str_replace('ء','ء',$LrixeNumber); 
$LrixeNumber = str_replace('ظ','ظِٰـﮧِۢ',$LrixeNumber); 
$LrixeNumber = str_replace('ط','طِٰـﮧِۢ',$LrixeNumber); 
 $LrixeNumber = str_replace('ذ','ذٰ',$LrixeNumber); 
$LrixeNumber = str_replace('د','د',$LrixeNumber); 
$LrixeNumber = str_replace('ز','ژ',$LrixeNumber); 
$LrixeNumber = str_replace('ر','رٰ',$LrixeNumber); 
$LrixeNumber = str_replace('و','ﯛ̲୭',$LrixeNumber); 
 $LrixeNumber = str_replace('ى','ىٍ',$LrixeNumber);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'parse_mode'=>"Markdown",
'text'=>$LrixeNumber."".$meme 
]);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
"text"=>'▫️ فونت شما اماده شد!',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"home"]],]])
]);}}
//ارتقا دهنده دیباگ کننده سورس @HOKOMAT_ARAB
//اولین چنل اوپن کننده @Virtualservices_3
//بی ناموسی منبع پاک کنی با افتخار به سعید افکونی
?>